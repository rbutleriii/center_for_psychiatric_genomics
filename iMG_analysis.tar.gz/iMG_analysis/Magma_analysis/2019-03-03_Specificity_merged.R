#!/usr/bin/env Rscript

# library(cqn)
library(dplyr)
library(biomaRt)
library(EWCE)
library(MAGMA.Celltyping)

############################
# Kozlova data prep
# load featureCounts tables for Kozlova data
setwd('/data/butlerr/iMG_analysis/Magma_analysis/')
fcounts_pe <- read.table("../bam_counts_pe/featureCounts_pe_counts.txt", 
                         header = T)
fcounts_se <- read.table("../bam_counts_se/featureCounts_se_counts.txt", 
                         header = T)

#unused column indices
uci <- -c(2:6)

# merge pe and se datasets for all fragment counts.
all_frag_count <- merge(fcounts_pe[ , uci], fcounts_se[ , uci], by = "Geneid")

# grabbing gene info for analysis from featurecounts, biomaRt
ensembl <- useMart("ensembl", dataset="hsapiens_gene_ensembl")
BMdat <- getBM(attributes = c("ensembl_gene_id",
                              "external_gene_name",
                              "hgnc_symbol",
                              "percentage_gene_gc_content",
                              "gene_biotype",
                              "chromosome_name"),
               filters = "ensembl_gene_id",
               values = all_frag_count$Geneid,
               mart = ensembl)
# three conflicting genes, remove indexes where external_gene_name and HGNC don't match
BMdat <- BMdat[ -c(16456, 29451, 53863), ]

# merging into features table for length, gc, and gene name
gene_features <- merge(fcounts_pe[order(fcounts_pe$Geneid), c(1,6)], 
                       BMdat,
                       by.x = "Geneid",
                       by.y = "ensembl_gene_id",
                       all.x = T)

# 1,546 duplicate entries multiple transcripts, keep longest
dups <- gene_features$external_gene_name[ duplicated(gene_features$external_gene_name) ]
dup_set <- gene_features[ (gene_features$external_gene_name %in% dups), ]
dup_set <- dup_set[order(dup_set$external_gene_name,-dup_set$Length),]
dup_rows <- as.vector(dup_set$Geneid[ duplicated(dup_set$external_gene_name) ])

# no missing gc values (0 genes)
nogc <- as.vector(gene_features[is.na(gene_features$percentage_gene_gc_content), "Geneid"])
nogc_counts <- all_frag_count[all_frag_count$Geneid %in% nogc,]

# no chrX,chrY values (2893 genes)
XY <- as.vector(gene_features[gene_features$chromosome_name %in% c("X", "Y"), "Geneid"])
XY_counts <- all_frag_count[all_frag_count$Geneid %in% XY,]

# keep only protein coding genes (19,951)
coding <- as.vector(gene_features[gene_features$gene_biotype == "protein_coding", "Geneid"])
coding_counts <- all_frag_count[all_frag_count$Geneid %in% coding,]

# 19,044 coding genes (of 58,735), keep intersection of coding and !(nogc) for final counts
final_frag_count <- all_frag_count[!(all_frag_count$Geneid %in% nogc) &
                                   !(all_frag_count$Geneid %in% XY) &
                                   !(all_frag_count$Geneid %in% dup_rows) &
                                   all_frag_count$Geneid %in% coding, ]
final_gene_features <- gene_features[!(gene_features$Geneid %in% nogc) &
                                     !(gene_features$Geneid %in% XY) &
                                     !(gene_features$Geneid %in% dup_rows) &
                                     gene_features$Geneid %in% coding, ]

# Cleaning up table
sum(final_frag_count$Geneid == final_gene_features$Geneid) == length(final_frag_count$Geneid)
row.names(final_frag_count) <- final_gene_features$external_gene_name
row.names(final_gene_features) <- final_gene_features$external_gene_name
final_frag_count <- final_frag_count[, -1]
final_frag_count <- final_frag_count %>%
  rename_at(.vars = vars(ends_with("_starAligned.sortedByCoord.out.bam")),
            .funs = list(~sub("_starAligned.sortedByCoord.out.bam$", "", .)))

# Rename samples
name <- read.table("../R_analysis_redux/new_names.txt",
                   header = T)
# Loop through replacing sample names
for(i in seq_along(name$Run)) {
  final_frag_count <- final_frag_count %>%
    rename_at(.vars = vars(starts_with("SRR")),
              .funs = list(~sub(name$Run[i], name$short_name[i], .)))
}
for(i in seq_along(name$Run)) {
  final_frag_count <- final_frag_count %>%
    rename_at(.vars = vars(starts_with("ERR")),
              .funs = list(~sub(name$Run[i], name$short_name[i], .)))
}

# freeing up some memory
remove(fcounts_pe, fcounts_se, all_frag_count, BMdat, ensembl, gene_features,
       nogc, nogc_counts, uci, name, coding, coding_counts, i, XY_counts, XY,
       dups, dup_rows, dup_set)


#############################################
# Filtering and ordering Kozlova datasets
# load sampleTable
sampleTable <- read.table("../R_analysis_redux/2019-01-08_sampleTable.txt", header = T)

# reorder columns like sampleTable
ctd_set <- final_frag_count[ , as.character(sampleTable$Name) ]

#check all there
names(ctd_set) == as.character(sampleTable$Name)

#rename columns
colnames(ctd_set) <- paste(sampleTable$cell_type, sampleTable$Center_Name,
                           sampleTable$Name, sep = '-')

# reorder by cell type
ctd_set <- ctd_set[ , order(names(ctd_set)) ]

remove(final_frag_count, final_gene_features, sampleTable)


#############################################
# Darmanis data prep

# Load sample data (see command.txt)
# generate sample data table from:
# GSE67835-GPL15520_series_matrix.txt.gz
# GSE67835-GPL18573_series_matrix.txt.gz
sampleTable_darm <- read.table("2019-02-06_sampleTable.txt", sep = "\t", 
                               header = T)
rownames(sampleTable_darm) <- sampleTable_darm$geo_accession

# sort by cell type
sampleTable_darm <- sampleTable_darm[ order(sampleTable_darm$cell_type, sampleTable_darm$geo_accession), ]

# drop unwanted from list
keep_set <- c('astrocytes', 'endothelial', 'microglia', 'neurons', 'oligodendrocytes')
sampleTable_darm <- sampleTable_darm[ sampleTable_darm$cell_type %in% keep_set, ]

# get files for import and verify all there
files <- Sys.glob(file.path('raw_counts', 
                            paste0(sampleTable_darm$geo_accession, '_', 
                                   sampleTable_darm$chip_id, '.*.csv.gz')),
                  dirmark = F)
names(files) <- sampleTable_darm$geo_accession
all(file.exists(files))

# generate count matrix
frag_counts <- lapply(files, function(x) {
  # read csv
  data <- read.table(gzfile(x),
                     sep = '\t',
                     header = F,
                     col.names = c('gene', names(files)[files == x]))
})
all_frag_count <- Reduce(function(x,y) merge(x = x, y = y, by = 'gene'),
                         frag_counts)

# fixing poorly annotated expression matrix data
# (common gene names instead of unique gene identifiers, also whitespace)
all_frag_count$gene <- trimws(all_frag_count$gene)
all_frag_count$gene <- sub(pattern = '([[:digit:]])ORF', replacement = '\\1orf', all_frag_count$gene)
rownames(all_frag_count) <- all_frag_count$gene
all_frag_count<- all_frag_count[, -1]
remove(frag_counts, files, keep_set)


#############################################
# Filtering and ordering Darmanis dataset, merging

# reorder columns like sampleTable
ctd_darmanis <- all_frag_count[ , as.character(sampleTable_darm$geo_accession) ]

#check all there
names(ctd_darmanis) == as.character(sampleTable_darm$geo_accession)

#rename columns
colnames(ctd_darmanis) <- paste(sampleTable_darm$cell_type, sampleTable_darm$geo_accession, sep = '-')

# reorder by cell type
ctd_darmanis <- ctd_darmanis[ , order(names(ctd_darmanis)) ]

remove(all_frag_count, sampleTable_darm)

###########################################
# Cleaning and merging for specificity

# check hgnc names
# fix.bad.hgnc.symbols(ctd_darmanis) error in script
# remove(all_hgnc)

# merge the two sets and prep for next step
ctd_merge <- merge(ctd_set, ctd_darmanis, by = "row.names")
rownames(ctd_merge) <- ctd_merge$Row.names
ctd_merge <- ctd_merge[ , -1 ]


#############################################
# Calculating specificity values
get_specificity_for_MGL <- function(MGL_name) {
  #'DC'=(ctd_merge[ , 1:3])
  #'Fib'=(ctd_merge[ , 4:7])
  #'iHPC'=(ctd_merge[ , 8:10])
  #'iMGL-Abud'=(ctd_merge[ , 11:13])
  #'iMGL-Brownjohn'=(ctd_merge[ , 14:19])
  #'iMGL-Kozlova'=(ctd_merge[ , 20:26])
  #'iPMP-Brownjohn'=(ctd_merge[ , 27:31])
  #'iPMP-Kozlova'=(ctd_merge[ , 32:33])
  #'iPS'=(ctd_merge[ , 34:38])
  #'MC'=(ctd_merge[ , 39:41])
  #'aMGL'=(ctd_merge[ , 42:44])
  #'fMGL'=(ctd_merge[ , 45:47])
  #'NSC'=(ctd_merge[ , 51:52])
  #'astrocytes'=(ctd_merge[ , 53:114])
  #'endothelial'=(ctd_merge[ , 115:134])
  #'microglia'=(ctd_merge[ , 135:150])
  #'neurons'=(ctd_merge[ , 151:281])
  #'oligodendrocytes'=(ctd_merge[ , 282:319])
  mgl_cols <- list("iMGL-Abud" = "11:13", "iMGL-Brownjohn" = "14:19", 
                   "iMGL-Kozlova" = "20:26", "iPMP-Brownjohn" = "27:31",
                   "iPMP-Kozlova" = "32:33", "aMGL" = "42:44", "fMGL" = "45:47",
                   "scMGL" = "135:150")
    
  # average column values in groups
  exp <- eval(parse(text=sprintf("data.matrix(ctd_merge[, c(1:3, 4:7, 39:41, 51:52, 53:114, 115:134, 151:281, 282:319, %s)])", 
                                 mgl_cols[MGL_name])))

  # generate annotation data
  mgl_length = eval(parse(text=sprintf("length(%s)", mgl_cols[MGL_name])))
  cell_type = c(rep('DC',3), rep('Fib',4), rep('MC',3), rep('NSC',2), rep('Ast', 62),
                rep('Endo', 20), rep('Neu', 131), rep('Olig', 38), rep(MGL_name, mgl_length))
  annot <- data.frame(cell_id=as.character(colnames(exp)),
                      data.frame(level1class=cell_type, stringsAsFactors = F), 
                      stringsAsFactors = F)
  
  # ctd object
  input_ctd <- list(exp=exp, annot=annot)
  
  # drop uninformative genes
  exp_dropped <- drop.uninformative.genes(exp=input_ctd$exp, level2annot=input_ctd$annot$level1class)
  
  # generate specificities
  annotLevels <- list(level1class=input_ctd$annot$level1class)
  fNames_out = generate.celltype.data(exp=exp_dropped,annotLevels=annotLevels,
                                      groupName=paste0(MGL_name, "_merged"))
  return(fNames_out)
}

get_specificity_for_MGL("iMGL-Abud")
get_specificity_for_MGL("iMGL-Brownjohn")
get_specificity_for_MGL("iMGL-Kozlova")
get_specificity_for_MGL("iPMP-Kozlova")
get_specificity_for_MGL("aMGL")
get_specificity_for_MGL("fMGL")
get_specificity_for_MGL("scMGL")







