#!/usr/bin/env Rscript

library(ggplot2)
library(reshape2)

setwd('/data/butlerr/iMG_analysis/Magma_analysis/')

# lists for parsing
gwas_list <- c("AD", "SCZ", "PD", "BMI")
sumstats_list <- c("BMI_sumstats", "AD_sumstats_Jansenetal",
                   "SCZ_sumstats", "PD_sumstats_Nalls_Nsum")
mgl_list <- c("aMGL", "fMGL", "iMGL-Abud", "iMGL-Brownjohn", "iMGL-Kozlova", 
              "iPMP-Kozlova", "scMGL")

# get files for import
lapply(sumstats_list, function(x) lapply(mgl_list, function(y) {
  file_pattern <- paste0("MAGMA_Files/", x, ".txt.10UP.1.5DOWN/", x, 
                         ".txt.10UP.1.5DOWN.level1.", y, "_merged.gsa.out") 
  newname <- paste(gsub(pattern = "_sumstats.*$", replacement = "", x, perl = T),
                   y, sep = "_")
  assign(newname, read.table(file = file_pattern, header = T), 
         inherits = T)
}))

# merge frames per GWAS
lapply(gwas_list, function(x) {
  temp_list <- lapply(mgl_list, function(k) paste(x, k, sep = "_"))
  df_list <- lapply(temp_list, function(y) get(y))
  result <- df_list[[1]]
  colnames(result)[-1] <- paste(colnames(result)[-1], mgl_list[1], sep = "_")
  for (i in head(seq_along(df_list), -1)) {
    result <- merge(x = result, y = df_list[[i+1]], by = "VARIABLE", 
                    suffixes = c(paste0("_", mgl_list[i]), 
                                 paste0("_", mgl_list[i+1])), all = T)
  }
  write.table(result, file = paste(Sys.Date(), x, "stats.txt", sep = "_"), 
              quote = F, row.names = F)
  assign(x, result, inherits = T)
})

# plot -log(P) values for percentiles
pdf(file = paste0(Sys.Date(), "_MAGMA_Pval_subsets.pdf"), 
    onefile = T, 
    paper = "USr",
    width = 11,
    height = 8.5)

for (k in gwas_list) {
  ggmelt <- melt(get(k)[ , c('VARIABLE', 'P_aMGL', 'P_fMGL', 'P_iMGL-Abud', 
                             'P_iMGL-Brownjohn', 'P_iMGL-Kozlova', 
                             'P_iPMP-Kozlova', 'P_scMGL') ], id.vars = 'VARIABLE')
  ggmelt$value <- -log10(ggmelt$value)
  ggAD <- ggplot(ggmelt, aes(x=VARIABLE, y=value, fill=variable)) +
    geom_bar(stat = "identity", position=position_dodge()) +
    scale_color_brewer(type = "qual", palette = "Set2") +
    ggtitle(paste0(k, " P-values")) + 
    labs(x="Cell type", y="-log10(P)", fill="Target MGL type") +
    theme_classic() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
  plot(ggAD)
}
dev.off()