#!/usr/bin/env bash
# for running all of the trimming, alignment and alignment-free pipelines
# does not make use of unpaired outputs from Trimmomatic
base_dir=/data/butlerr/microglia_iPSC

# STAR mapping task
for k in pe se; do
  # trim reads
  cd ${base_dir}/trimmed_${k}
  ./command.txt && wait
  # STAR-featureCounts pipeline
  cd ${base_dir}/bam_counts_${k}
  ./command.txt && wait
done
cd ${base_dir}

