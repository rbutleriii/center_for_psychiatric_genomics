#!/usr/bin/env bash

# if needed to convert sra files to fastq
for k in *.sra; do
  fasterq-dump -e 100 -p --split-files --skip-technical $k
done

# will archive sra files after completion
tar -cvf - *.sra | pigz -v > sra_archive.tar.gz
