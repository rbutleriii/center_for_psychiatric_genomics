#!/usr/bin/env Rscript

library(ggplot2)
library(reshape2)
library(ggridges)
library(ggrepel)

setwd('/data/butlerr/iMG_analysis/R_analysis_redux/')

###############################################
# load datasets
specificity_sets <- c("aMGL", "fMGL", "iMGL-Abud", "iMGL-Brownjohn", 
                      "iMGL-Kozlova", "iPMP-Kozlova", "scMGL")
ctd_list <- sprintf("ctd_%s", specificity_sets)
lapply(specificity_sets, function(x) {
  load(sprintf("../Magma_analysis/CellTypeData_%s_merged.rda", x))
  assign(sprintf("ctd_%s", x), ctd, inherits = T)
})
remove(ctd_list)

# specificity big table
specificity_tbl <- as.data.frame(ctd_aMGL[[1]]$specificity)
# add other MGL/PMP sets, the lazy way
fMGL <- data.frame("fMGL"=ctd_fMGL[[1]]$specificity[,"fMGL"])
iMGL_Abud <- data.frame("iMGL_Abud"=`ctd_iMGL-Abud`[[1]]$specificity[,"iMGL-Abud"])
iMGL_Brownjohn <- data.frame("iMGL_Brownjohn"=`ctd_iMGL-Brownjohn`[[1]]$specificity[,"iMGL-Brownjohn"])
iMGL_Kozlova <- data.frame("iMGL_Kozlova"=`ctd_iMGL-Kozlova`[[1]]$specificity[,"iMGL-Kozlova"])
iPMP_Kozlova <- data.frame("iPMP_Kozlova"=`ctd_iPMP-Kozlova`[[1]]$specificity[,"iPMP-Kozlova"])
scMGL <- data.frame("scMGL"=ctd_scMGL[[1]]$specificity[,"scMGL"])

# join frames
spec_list <- list(specificity_tbl, fMGL, iMGL_Abud, iMGL_Brownjohn, 
                  iMGL_Kozlova, iPMP_Kozlova, scMGL)
spec_list <- lapply(spec_list, function(x) {x$gene <- rownames(x);return(x)})
all_specs <- Reduce(function(x, y) merge(x = x, y = y, by = 'gene', all = T), 
                    spec_list)

# clean up
# rownames(all_specs) <- all_specs$gene
all_specs <- all_specs[, c('gene', 'iMGL_Abud', 'MC', 'scMGL', 'aMGL', 'fMGL', 
                            'iMGL_Brownjohn', 'iMGL_Kozlova', 'iPMP_Kozlova',
                            'Endo', 'DC', 'Fib', 'NSC', 'Ast', 'Neu', 'Olig')]
# all_specs[is.na(all_specs)] <- 0
all_specs[all_specs == 0] <- NA
remove(ctd_aMGL,ctd_fMGL,`ctd_iMGL-Abud`, `ctd_iMGL-Brownjohn`, 
       `ctd_iMGL-Kozlova`,`ctd_iPMP-Kozlova`,ctd_scMGL,fMGL,iMGL_Abud,scMGL,
       iMGL_Brownjohn,iMGL_Kozlova,iPMP_Kozlova, specificity_tbl,spec_list)

##############################################
# joy plot
# selecting only AD genes form haenseler et al
haenseler <- scan(file = "Haenseler_genes.txt", what = "", sep = "\n")

# only first 31 are AD
haenseler_AD <- haenseler[1:31]

# prepping data (melt and label strip)
ggmelt <- melt(all_specs, id.vars = 'gene')
ggmelt$gene <- ifelse(ggmelt$gene %in% haenseler_AD, ggmelt$gene, "")

# plotting
pdf(file = paste0(Sys.Date(), "_specificity_joy_plot.pdf"), 
    onefile = T, 
    paper = "USr",
    width = 11,
    height = 8.5)

ggJoy <- ggplot(ggmelt, aes(x=value, y=variable, label=gene, fill=factor(..quantile..))) +
  stat_density_ridges(geom = "density_ridges_gradient", calc_ecdf = T,
                      quantiles = 10, quantile_lines = F) + 
  scale_fill_brewer(type = "div", palette = "RdYlBu", direction = -1) +
  scale_x_log10(limits = c(5e-04,1)) +
  # geom_text_repel() +
  labs(x="Specificity", y="Cell type", fill="Decile") + theme_classic()

plot(ggJoy)
dev.off()


