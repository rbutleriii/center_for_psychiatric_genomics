#!/usr/bin/env Rscript

library(EWCE)
library(biomaRt)

setwd('/data/butlerr/iMG_analysis/ldsc/')

# load datasets
specificity_sets <- c("aMGL", "fMGL", "iMGL-Abud", "iMGL-Brownjohn", "iMGL-Kozlova", "iPMP-Kozlova", "scMGL")
ctd_list <- sprintf("ctd_%s", specificity_sets)
lapply(specificity_sets, function(x) {
  load(sprintf("../Magma_analysis/CellTypeData_%s_merged.rda", x))
  assign(sprintf("ctd_%s", x), ctd, inherits = T)
})
remove(ctd_list)

# generate control gene_list for ldsc (13,989 were kept from specificity analysis) 
union_list <- c(rownames(ctd_aMGL[[1]]$specificity), 
                rownames(ctd_fMGL[[1]]$specificity),
                rownames(`ctd_iMGL-Abud`[[1]]$specificity),
                rownames(`ctd_iMGL-Brownjohn`[[1]]$specificity),
                rownames(`ctd_iMGL-Kozlova`[[1]]$specificity),
                rownames(`ctd_iPMP-Kozlova`[[1]]$specificity),
                rownames(ctd_scMGL[[1]]$specificity)
                )
control_geneset <- union_list[!duplicated(union_list)]

# convert all to ENSG
ensembl <- useMart("ensembl", dataset="hsapiens_gene_ensembl")
BMdat <- getBM(attributes = c("external_gene_name", "ensembl_gene_id", "transcription_start_site"),
               filters = "external_gene_name",
               values = control_geneset,
               mart = ensembl)

# Lots of duplicate entries multiple transcripts, keep earliest TSS
dup_set <- BMdat[order(BMdat$external_gene_name,BMdat$transcription_start_site), ]
dup_set <- dup_set[ !duplicated(dup_set$external_gene_name), ]

# control set
write.table(dup_set$ensembl_gene_id, file = 'Kozlova_top20_1000Gv3_ldscores/Kozlova_top20.control.GeneSet', quote = F, row.names = F, col.names = F)

# Clean
remove(ensembl, BMdat, union_list)

# specificity big table
specificity_tbl <- as.data.frame(ctd_aMGL[[1]]$specificity)
# add other MGL/PMP sets, the lazy way
fMGL <- data.frame("fMGL"=ctd_fMGL[[1]]$specificity[,"fMGL"])
iMGL_Abud <- data.frame("iMGL_Abud"=`ctd_iMGL-Abud`[[1]]$specificity[,"iMGL-Abud"])
iMGL_Brownjohn <- data.frame("iMGL_Brownjohn"=`ctd_iMGL-Brownjohn`[[1]]$specificity[,"iMGL-Brownjohn"])
iMGL_Kozlova <- data.frame("iMGL_Kozlova"=`ctd_iMGL-Kozlova`[[1]]$specificity[,"iMGL-Kozlova"])
iPMP_Kozlova <- data.frame("iPMP_Kozlova"=`ctd_iPMP-Kozlova`[[1]]$specificity[,"iPMP-Kozlova"])
scMGL <- data.frame("scMGL"=ctd_scMGL[[1]]$specificity[,"scMGL"])

# join frames
spec_list <- list(specificity_tbl, fMGL, iMGL_Abud, iMGL_Brownjohn, iMGL_Kozlova, iPMP_Kozlova, scMGL)
spec_list <- lapply(spec_list, function(x) {x$gene <- rownames(x);return(x)})
all_specs <- Reduce(function(x, y) merge(x = x, y = y, by = 'gene', all = T), spec_list)

# match to ENSG IDs
all_specs <- merge(all_specs, dup_set[,1:2], by.x = 'gene', by.y = 'external_gene_name')

# clean up
rownames(all_specs) <- all_specs$ensembl_gene_id
all_specs <- all_specs[ , c('MC', 'aMGL', 'fMGL', 'iMGL_Kozlova', 'iMGL_Brownjohn',
                            'iMGL_Abud', 'scMGL', 'iPMP_Kozlova', 'Ast', 'DC',
                            'Endo', 'Olig', 'Neu', 'NSC', 'Fib') ]
all_specs[is.na(all_specs)] <- 0

# top 10% of each
cnt <- 0
for (k in colnames(all_specs)) {
  cnt <- cnt + 1
  top20_set <- subset(rownames(all_specs), all_specs[[k]] > quantile(all_specs[[k]], probs = 0.8))
  write.table(top20_set, file = sprintf("Kozlova_top20_1000Gv3_ldscores/Kozlova_top20.%s.GeneSet", cnt),
              quote = F, row.names = F, col.names = F)
  assign(sprintf("%s_geneset", k), top20_set, inherits = T)
}
