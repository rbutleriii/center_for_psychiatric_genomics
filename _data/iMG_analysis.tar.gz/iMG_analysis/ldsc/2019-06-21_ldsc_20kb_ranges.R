#!/usr/bin/env Rscript

library(ggplot2)
library(reshape2)

# setwd('/media/sf_E_DRIVE/microglia_iPSC/ldsc/')
# setwd('/Volumes/botweiser/microglia_iPSC/ldsc/')
setwd('/data/butlerr/microglia_iPSC/ldsc/')

# get files for import and verify all there
files <- Sys.glob('*20kb*.cell_type_results.txt') 
all(file.exists(files))
lapply(files, function(x) {
  assign(gsub(pattern = ".cell_type_results.txt", replacement = "", x), 
         read.table(file = x, header = T, sep = "\t"), inherits = T)
})

# merge frames per GWAS
gwas_list <- c("Jan_AD", "PGC_SCZ", "Nalls_PD", "PGC_ASD", "PGC_BIP", "PGC_MDD",
               "BMI", "Height")
percen_list <- c("", "_top20", "_top30", "_top40", "_top50")
lapply(gwas_list, function(x) {
  temp_list <- lapply(percen_list, function(k) paste0(x, "_Kozlova_20kb", k))
  df_list <- lapply(temp_list, function(y) get(y))
  result <- df_list[[1]]
  for (i in head(seq_along(df_list), -1)) {
    result <- merge(x = result, y = df_list[[i+1]], by = "Name", 
                    suffixes = c("", percen_list[i+1]))
  }
  write.table(result, file = paste(Sys.Date(), x, "20kb_stats.txt", sep = "_"), quote = F, row.names = F)
  assign(x, result, inherits = T)
})

# plot -log(P) values for percentiles
pdf(file = paste0(Sys.Date(), "_ldsc_20kb_Pval_percentiles.pdf"), 
    onefile = T, 
    paper = "USr",
    width = 11,
    height = 8.5)

for (k in gwas_list) {
  ggmelt <- melt(get(k)[ , c('Name', 'Coefficient_P_value', 'Coefficient_P_value_top20', 'Coefficient_P_value_top30', 
                        'Coefficient_P_value_top40', 'Coefficient_P_value_top50') ], id.vars = 'Name')
  ggmelt$value <- -log10(ggmelt$value)
  ggmelt$variable <- gsub("Coefficient_P_value_", "", ggmelt$variable)
  ggmelt$variable <- gsub("Coefficient_P_value", "top10", ggmelt$variable)
  ggAD <- ggplot(ggmelt, aes(x=Name, y=value, fill=variable)) +
    geom_bar(stat = "identity", position=position_dodge()) +
    scale_color_brewer(type = "qual", palette = "Set2") +
    ggtitle(paste0(k, " P-values")) + 
    labs(x="Cell type", y="-log10(P)", fill="Specificity percentile") +
    theme_classic() + theme(axis.text.x = element_text(angle = 45, hjust = 1))
  plot(ggAD)
}
dev.off()