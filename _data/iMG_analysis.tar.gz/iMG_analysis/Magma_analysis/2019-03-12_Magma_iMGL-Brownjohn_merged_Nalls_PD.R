#!/usr/bin/env Rscript

# library(R.utils)
library(MAGMA.Celltyping)

mgl_type="iMGL-Brownjohn_merged"
upstr=10
dwnstr=1.5
setwd('/data/butlerr/iMG_analysis/Magma_analysis/')

# Set path the 1000 genomes reference data.
genome_ref_dir = "/data/butlerr/iMG_analysis/references/bed/g1000_eur"
genome_ref_path = sprintf("%s/g1000_eur", genome_ref_dir)

# Load the celltype data
load(sprintf('CellTypeData_%s.rda', mgl_type))

ctd = prepare.quantile.groups(ctd, specificity_species="human", numberOfBins=10)

# Download and unzip the summary statistics file
gwas_sumstats_path = "/data/butlerr/iMG_analysis/Magma_analysis/PD_sumstats_Nalls_Nsum.txt"

##################################
# Variable upstr, dwnstr
# Map SNPs to Genes
genesOutPath = map.snps.to.genes(gwas_sumstats_path, genome_ref_path=genome_ref_path, 
                                 upstream_kb=upstr, downstream_kb=dwnstr)

# linear enrichment
ctAssocsLinear = calculate_celltype_associations(ctd, gwas_sumstats_path, genome_ref_path=genome_ref_path,
                                                 specificity_species="human", analysis_name=mgl_type,
                                                 upstream_kb=upstr, downstream_kb=dwnstr)
FigsLinear = plot_celltype_associations(ctAssocsLinear, ctd=ctd, fileTag=mgl_type)

# top 10%
ctAssocsTop = calculate_celltype_associations(ctd, gwas_sumstats_path, genome_ref_path=genome_ref_path,
                                              specificity_species="human", EnrichmentMode="Top 10%",
                                              analysis_name=paste0(mgl_type, "top10"), upstream_kb=upstr,
                                              downstream_kb=dwnstr)
FigsTopDecile = plot_celltype_associations(ctAssocsTop, ctd=ctd, fileTag=mgl_type)

# plot both together
ctAssocMerged = merge_magma_results(ctAssocsLinear, ctAssocsTop)
FigsMerged = plot_celltype_associations(ctAssocMerged, ctd=ctd, fileTag=mgl_type)
