#!/usr/bin/env Rscript

# library(R.utils)
library(MAGMA.Celltyping)

mgl_type="iMGL-Brownjohn_merged"
upstr=10
dwnstr=1.5
# setwd('/media/sf_E_DRIVE/microglia_iPSC/Magma_analysis/')
# setwd('/Volumes/botweiser/microglia_iPSC/Magma_analysis/')
setwd('/data/butlerr/microglia_iPSC/Magma_analysis/')

# Set path the 1000 genomes reference data.
# genome_ref_dir = "/media/sf_E_DRIVE/reference/bed/g1000_eur"
# genome_ref_dir = "/Volumes/botweiser/reference/bed/g1000_eur"
genome_ref_dir = "/data/butlerr/reference/bed/g1000_eur"
# if(!file.exists(sprintf("%s/g1000_eur.bed",genome_ref_dir))){
#   download.file("https://ctg.cncr.nl/software/MAGMA/ref_data/g1000_eur.zip",destfile=sprintf("%s.zip",genome_ref_dir))
#   unzip(sprintf("%s.zip",genome_ref_dir),exdir=genome_ref_dir)
# }
genome_ref_path = sprintf("%s/g1000_eur", genome_ref_dir)

# Load the celltype data
load(sprintf('CellTypeData_%s.rda', mgl_type))
#ctd <- ctd_AIBS

ctd = prepare.quantile.groups(ctd, specificity_species="human", numberOfBins=10)

# Download and unzip the summary statistics file
gwas_sumstats_path = "/data/butlerr/microglia_iPSC/Magma_analysis/BMI_sumstats.txt"

##################################
# Variable upstr, dwnstr
# Map SNPs to Genes
genesOutPath = map.snps.to.genes(gwas_sumstats_path, genome_ref_path=genome_ref_path, 
                                 upstream_kb=upstr, downstream_kb=dwnstr)

# linear enrichment
ctAssocsLinear = calculate_celltype_associations(ctd, gwas_sumstats_path, genome_ref_path=genome_ref_path,
                                                 specificity_species="human", analysis_name=mgl_type,
                                                 upstream_kb=upstr, downstream_kb=dwnstr)
FigsLinear = plot_celltype_associations(ctAssocsLinear, ctd=ctd, fileTag=mgl_type)

# top 10%
ctAssocsTop = calculate_celltype_associations(ctd, gwas_sumstats_path, genome_ref_path=genome_ref_path,
                                              specificity_species="human", EnrichmentMode="Top 10%",
                                              analysis_name=paste0(mgl_type, "top10"), upstream_kb=upstr,
                                              downstream_kb=dwnstr)
FigsTopDecile = plot_celltype_associations(ctAssocsTop, ctd=ctd, fileTag=mgl_type)

# plot both together
ctAssocMerged = merge_magma_results(ctAssocsLinear, ctAssocsTop)
FigsMerged = plot_celltype_associations(ctAssocMerged, ctd=ctd, fileTag=mgl_type)
