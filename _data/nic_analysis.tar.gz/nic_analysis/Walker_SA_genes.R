#!/usr/bin/env Rscript

library(data.table)
library(biomaRt)


#####################################################
# Basic function to convert mouse to rat gene names
convertRatGeneList = function(x){
  require("biomaRt")
  mouse = useEnsembl("ensembl", dataset="mmusculus_gene_ensembl", version="99")
  # match with ensembl_gene_id across both
  genes = getBM(mart=mouse, filters="external_gene_name", values=x, 
                attributes=c("rnorvegicus_homolog_ensembl_gene"))
  x = unique(genes)
  # Print the first 6 genes found to the screen
  print(head(x))
  return(x)
}


# read genelist files and convert to rat
write_converts = function(infile, outfile){
  a = fread(infile)
  mylist = names(a)
  step1 = lapply(mylist, function(k) convertRatGeneList(a[[k]]))
  setattr(step1, 'names', mylist)
  step2 = rbindlist(step1, id='sets')
  fwrite(step2, quote=F, sep="\t", file=outfile)
}
write_converts("Walker_AdIn_genes.txt", "Walker_AdIn_ensrog.txt")
write_converts("Walker_SA_genes.txt", "Walker_SA_ensrog.txt")
