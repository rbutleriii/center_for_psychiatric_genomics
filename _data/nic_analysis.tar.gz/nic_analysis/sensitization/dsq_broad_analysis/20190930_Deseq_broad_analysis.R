#!/usr/bin/env Rscript

library(tximport)
library(readr)
library(DESeq2)
library(biomaRt)
library(magrittr)
library(BiocParallel)
library(vsn)
library(pheatmap)
library(RColorBrewer)
library(ggplot2)
library(ggrepel)
library(gridExtra)
library(dplyr)
library(PoiClaClu)
library(jsonlite)


# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/sensitization/dsq_broad_analysis'))
# file naming info
today = format(Sys.Date(), '%Y%m%d')
nameset = '_salmon_Dsq2_'
# database to draw from
ensembl = useEnsembl("ensembl", dataset="rnorvegicus_gene_ensembl", version="96")
# Load sample data
sampleTable = read.table(paste0(rootdir, "/sensitization/20190706_sampleTable.txt"),
                         header=T)
# what annotation columns are the sample names and file names coming from?
samp_names = "name"
files_header = "run"
# secondary name
secon_name = "trt"
# don't forget to define pca functions at the bottom

#################################
# Building dds from salmon counts
# get files for import
files = Sys.glob(file.path(rootdir, 'salmon', sampleTable[[files_header]], 
                           'quant.sf'), dirmark=T)
names(files) = sampleTable[[samp_names]]

# checking if all the samples have salmon files
if (!all(file.exists(files))) {
  print("Missing some of the sample files!")
  quit("no", 1)
}

# fetch sample/mapping quality info
read_dups = numeric(length(sampleTable[[files_header]]))
map_rate = numeric(length(sampleTable[[files_header]]))
# files_col = sampleTable[[files_header]]
for (i in 1:length(sampleTable[[files_header]])) {
  # fastp duplicate read proportion
  j = fromJSON(paste0(rootdir, "/trimmed/", sampleTable[[files_header]][i],
                      ".json"))
  read_dups[i] = j$duplication$rate
  # salmon percent of reads mapped
  k = fromJSON(paste0(rootdir, "/salmon/", sampleTable[[files_header]][i], 
                      "/aux_info/meta_info.json"))
  map_rate[i] = k$percent_mapped
}
# merge and add to sampleTable
mapframe = data.frame(read_dups, map_rate)
rownames(mapframe) = sampleTable[[files_header]]
sampleTable = merge(sampleTable, mapframe, by.x=files_header, by.y=0, all.x=T)
rownames(sampleTable) = sampleTable[[samp_names]]

# tximport transcripts (reorder to match merged table above)
files = files[order(factor(names(files), levels=c(rownames(sampleTable))))]
txi.tx = tximport(files, type='salmon', txOut=T)

# generate gene-level summarization
if(!file.exists("tx2gene.txt")){
  tx2gene = getBM(attributes=c("ensembl_transcript_id", "ensembl_gene_id"),
                  filters="ensembl_transcript_id_version",
                  values=rownames(txi.tx$counts), mart=ensembl)
  write.table(tx2gene, file="tx2gene.txt", sep="\t", quote=F, row.names = F)
}
tx2gene = read.table("tx2gene.txt", header=T)

# convert to gene level
txi.gene = summarizeToGene(txi.tx, tx2gene, ignoreTxVersion=T)

#import to DESeq
rownames(sampleTable)==colnames(txi.gene$counts)
dds = DESeqDataSetFromTximport(txi.gene, sampleTable, ~ sex + trt)

# cleanup
remove(tx2gene, files, txi.tx, txi.gene, sampleTable, i, j, k, mapframe, 
       read_dups, map_rate)


##########################
# Prep and Normalization
# looking at sample info
dds$trt %<>% relevel("sal")
dds$sex %<>% relevel("F")

# gene info for filtering by gene biotype
if(!file.exists("gene_info.txt")){
  gene_info = getBM(attributes=c("ensembl_gene_id", "external_gene_name",
                                 "gene_biotype", "chromosome_name"),
                    filters="ensembl_gene_id", values=rownames(dds),
                    mart=ensembl)
  write.table(gene_info, file="gene_info.txt", sep="\t", quote=F, row.names=F)
}
gene_info = read.table("gene_info.txt", header=T)

# ensembl transcript types to keep, excluding pseudogenes and small RNAs
# restricting to only protein coding and long rna
keep_categ = c('3prime_overlapping_ncRNA',
               'antisense',
               'bidirectional_promoter_lncRNA',
               'IG_C_gene',
               'IG_D_gene',
               'IG_J_gene',
               'IG_V_gene',
               'lincRNA',
               'macro_lncRNA',
               'non_coding',
               'processed_transcript',
               'protein_coding',
               'ribozyme', 
               'sense_intronic',
               'sense_overlapping', 
               'TR_C_gene',
               'TR_D_gene',
               'TR_J_gene',
               'TR_V_gene')#, 
               #'vaultRNA')

# filter low count genes (n-1 of smallest group is 6)
print(paste(nrow(dds), "unfiltered genes"))
dds = estimateSizeFactors(dds)
dds = dds[ rowSums( counts(dds, normalized=T) >= 5 ) >= 6, ]
print(paste(nrow(dds), "filtered genes"))

# filter by gene type
use_genes = gene_info$ensembl_gene_id[ gene_info$gene_biotype %in% keep_categ ]
dds = dds[ rownames(dds) %in% use_genes ]

# use only canonicanl chromosomes
use_chrs = gene_info$ensembl_gene_id[ 
  grep("^\\d{1,2}|X|Y" , gene_info$chromosome_name, perl=T) ]
dds = dds[ rownames(dds) %in% use_chrs ]

# add gene names annotation
mcols(dds) = DataFrame(mcols(dds), symbol=gene_info$external_gene_name[ 
    match(rownames(dds), gene_info$ensembl_gene_id) ])

# vst transform
vst = vst(dds)

# checking normalization
# this gives log2(n + 1) transformation
ntd = normTransform(dds)
# plot variances for both transformations
plot_1 = meanSdPlot(assay(ntd))
plot_2 = meanSdPlot(assay(vst))
ml = marrangeGrob(list(plot_1$gg, plot_2$gg), nrow=1, ncol=2, respect=T)
ggsave(paste0(today, nameset, "normalization.pdf"), ml, width=11, height=8.5, 
       useDingbats=F)

remove(ntd, ml, plot_1, plot_2, ensembl, keep_categ, use_chrs, use_genes)


#############################
# Poisson Distance Pairwise
poisd = PoissonDistance(t(counts(dds)))
samplePoisDistMatrix = as.matrix(poisd$dd)
rownames(samplePoisDistMatrix) = paste(dds[[samp_names]], dds[[secon_name]], 
                                       sep=" - ")
colnames(samplePoisDistMatrix) = paste(dds[[samp_names]], dds[[secon_name]], 
                                       sep=" - ")

# set colors and draw
colors = colorRampPalette(brewer.pal(11, "RdYlBu"))(255)
pheatmap(samplePoisDistMatrix, col=colors, clustering_distance_rows=poisd$dd,
         clustering_distance_cols=poisd$dd, width=11, height=8.5,
         filename=paste0(today, nameset, "poisson.pdf"))

remove(poisd, samplePoisDistMatrix)


###############################
# PCA top X genes by variance
# c_by = column to color by
# c_lab = Label for color legend
# c_type = "disc" discrete or "cont" continuous coloring
# num = number of genes, default is all
my_pca_plot = function(vst, c_by, c_lab, c_type="disc", num=1000000) {
  rv = rowVars(assay(vst))
  top_genes = order(rv, decreasing=T)[seq_len(min(num, length(rv)))]
  pca = prcomp(t(assay(vst)[top_genes, ]))
  percent_pc = round((pca$sdev^2 / sum(pca$sdev^2))*100, 2)
  if (c_type == "disc") {
    col_by = as.factor(vst[[c_by]])
  } else if (c_type == "cont") {
    col_by = vst[[c_by]]
  } else {
    print("Incorrect value for c_type!")
    quit("no", 1)
  }

  # PC1 v PC2
  ggPCA12 = ggplot(data.frame(pca$x), aes(x=PC1, y=PC2, col=col_by)) +
    labs(x=sprintf("PC1 - %.2f%%", percent_pc[1]),
         y=sprintf("PC2 - %.2f%%", percent_pc[2]), col=c_lab) +
    geom_point(size=3, alpha=0.5) +
    geom_text_repel(aes(label=rownames(data.frame(pca$x)))) +
    ggtitle(sprintf("top %s genes", length(top_genes))) + theme_classic() + {
      if(c_type == "disc") scale_color_brewer(type="qual", palette="Paired") 
      else scale_color_distiller(type="div", palette="RdYlBu")
    }

  # PC1 v PC3
  ggPCA13 = ggplot(data.frame(pca$x), aes(x=PC1, y=PC3, col=col_by)) +
    labs(x=sprintf("PC1 - %.2f%%", percent_pc[1]),
         y=sprintf("PC3 - %.2f%%", percent_pc[3]), col=c_lab) +
    geom_point(size=3, alpha=0.5) +
    geom_text_repel(aes(label=rownames(data.frame(pca$x)))) +
    ggtitle(sprintf("top %s genes", length(top_genes))) + theme_classic() + {
      if(c_type == "disc") scale_color_brewer(type="qual", palette="Paired") 
      else scale_color_distiller(type="div", palette="RdYlBu")
    }
  plot(ggPCA12)
  plot(ggPCA13)
}


#################################
# PCA plotting 
pdf(file=paste0(today, nameset, "pca.pdf"), onefile=T, paper="USr", width=11, 
    height=8.5)
my_pca_plot(vst, c_by="tissue", c_lab="Tissue", c_type="disc")
my_pca_plot(vst, c_by="prep_batch", c_lab="Prep_batch", c_type="disc")
my_pca_plot(vst, c_by="read_dups", c_lab="Read Dups", c_type="cont")
my_pca_plot(vst, c_by="map_rate", c_lab="Map Rate", c_type="cont")
my_pca_plot(vst, c_by="tissue", c_lab="Top 500 Tissue", c_type="disc", num=500)
my_pca_plot(vst, c_by="sex", c_lab="Top 500 Sex", c_type="disc", num=500)
my_pca_plot(vst, c_by="trt", c_lab="Top 500 Nicotine", c_type="disc", num=500)
dev.off()


# save DESeqDataSet for future use
save(dds, file=paste0(today, nameset, 'dds.Rdata'), compress=T)

