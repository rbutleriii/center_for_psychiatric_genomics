#!/usr/bin/env Rscript

library(data.table)

setwd('/data/butlerr/nicotine_sensi/sensitization/dsq_split_downgenes')
today = format(Sys.Date(), '%Y%m%d')
nameset = "_dsq_split_down_"
de_dir= '/data/butlerr/nicotine_sensi/sensitization/dsq_split_DE_analysis'
# thresholds
l2fc = 0
plist = list("ultrawide"=0.05)
# files
target_files = paste0(de_dir, "/20191211_dsq_split_DEgenes_")
file_tails = c("resFnac", "resFnash", "resFvta", "resMnac", "resMnash", 
               "resMvta")

#################################FUNCTIONS
# subset the down DE sets by pval threshold
gene_list = function (file, pval, lfc, outname) {
  genes = file_data[ FILE == file & !is.na(pvalue) & pvalue < pval 
                    & log2FoldChange < -(lfc) ]
  f1 = paste0(today, nameset, outname, "_", file, ".txt")
  fwrite(list(genes$ensembl_gene_id), quote=F, col.names=F, file=f1)
}

#################################MAIN
# reading in tables, combine and melt by GWAS
file_list = lapply(file_tails, function(x) fread(file=paste0(target_files, x, ".txt")))
setattr(file_list, 'names', file_tails)
file_data = rbindlist(file_list, use.names=T, idcol="FILE")
setnames(file_data, "V1", "ensembl_gene_id")
back = unique(file_data[, c("ensembl_gene_id", "symbol")])
fwrite(back, quote=F, sep='\t', file=paste0(today, nameset, "background.txt"))

# generate human gene lists
for (i in seq(plist)) {
  lapply(file_tails, function(x) gene_list(x, plist[[i]], l2fc, names(plist)[i]))
}

