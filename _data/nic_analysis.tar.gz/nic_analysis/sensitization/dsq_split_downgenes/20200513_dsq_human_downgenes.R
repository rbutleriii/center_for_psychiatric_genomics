#!/usr/bin/env Rscript

library(biomaRt)
library(data.table)

setwd('/data/butlerr/nicotine_sensi/sensitization/dsq_split_downgenes')
today = format(Sys.Date(), '%Y%m%d')
nameset = "_dsq_split_human_down_"
# thresholds
l2fc = 0
plist = list("ultrawide"=0.05)
# files
de_dir= '/data/butlerr/nicotine_sensi/sensitization/dsq_split_DE_analysis'
target_files = paste0(de_dir, "/20191211_dsq_split_DEgenes_")
file_tails = c("resFnac", "resFnash", "resFvta", "resMnac", "resMnash", 
               "resMvta")
bac_file = "20200513_dsq_split_down_background.txt"

#################################FUNCTIONS
# Basic function to convert mouse to human gene names
convertRatGeneList = function(x){
  require("biomaRt")
  rat = useEnsembl("ensembl", dataset="rnorvegicus_gene_ensembl", version="99")
  # match with ensembl_gene_id across both
  genes = getBM(mart=rat, filters="ensembl_gene_id", values=x, 
                attributes=c("ensembl_gene_id", "chromosome_name", 
                             "start_position", "end_position", 
                             "hsapiens_homolog_ensembl_gene", 
                             "hsapiens_homolog_associated_gene_name"))
  # Print the first 6 genes found to the screen
  print(head(unique(genes)))
  return(unique(genes))
}

# subset the human down DE sets by pval threshold
gene_list = function (file, pval, lfc, outname) {
  genes = file_data[ FILE == file & !is.na(pvalue) & pvalue < pval 
                    & log2FoldChange < -(lfc) ]
  out = matches[ ensembl_gene_id %in% genes$ensembl_gene_id ]
  f1 = paste0(today, nameset, outname, "_", file, ".txt")
  fwrite(list(unique(out$hsapiens_homolog_ensembl_gene)), quote=F, col.names=F, 
         file=f1)
}

# subset the human down DE sets by pval threshold no XY genes
gene_lstXY = function (file, pval, lfc, outname) {
  genes = file_data[ FILE == file & !is.na(pvalue) & pvalue < pval 
                    & log2FoldChange < -(lfc) ]
  out = matches[ ensembl_gene_id %in% genes$ensembl_gene_id 
                & !(chromosome_name %in% c("X", "Y")) ]
  f1 = paste0(today, nameset, "noXY_", outname, "_", file, ".txt")
  fwrite(list(unique(out$hsapiens_homolog_ensembl_gene)), quote=F, col.names=F, 
         file=f1)
}

##################################MAIN
# background set
if(!file.exists(paste0(today, nameset, "M-Hlookup.txt"))){
  background = fread(bac_file, header=T)
  bac_genes = data.table(convertRatGeneList(background$ensembl_gene_id))
  # only those with matches
  matches = bac_genes[ hsapiens_homolog_ensembl_gene != "" ]
  fwrite(list(unique(matches$hsapiens_homolog_ensembl_gene)), quote=F, 
         col.names=F, file=paste0(today, nameset, "background.txt"))
  # set aside autosomes
  noXY = matches[ !(chromosome_name %in% c("X", "Y")) ]
  fwrite(list(unique(noXY$hsapiens_homolog_ensembl_gene)), quote=F, col.names=F, 
         file=paste0(today, nameset, "noXY_background.txt"))
  fwrite(bac_genes, quote=F, sep="\t", 
         file=paste0(today, nameset, "M-Hlookup.txt"))
} else {
  bac_genes = fread(paste0(today, nameset, "M-Hlookup.txt"))
  matches = bac_genes[ hsapiens_homolog_ensembl_gene != "" ]
}

# reading in tables, combine and melt by GWAS
file_list = lapply(file_tails, function(x) fread(file=paste0(target_files, x, ".txt")))
setattr(file_list, 'names', file_tails)
file_data = rbindlist(file_list, use.names=T, idcol="FILE")
setnames(file_data, "V1", "ensembl_gene_id")

# generate human gene lists
for (i in seq(plist)) {
  lapply(file_tails, function(x) gene_list(x, plist[[i]], l2fc, names(plist)[i]))
  lapply(file_tails, function(x) gene_lstXY(x, plist[[i]], l2fc, names(plist)[i]))
}

