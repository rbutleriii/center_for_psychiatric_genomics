#!/usr/bin/env bash

# script to generate a table of gene lists for DAVID
# paths to directory, date, and target file prefix
de_dir='/data/butlerr/nicotine_sensi/sensitization/dsq_split_DE_analysis/'
de_date='20200317'
target_files='_dsq_split_l2fc_human_ultrawide_res'
# write table header
ls ${de_dir}${de_date}${target_files}*.txt \
  | xargs -n1 basename \
  | sed "s/${de_date}${target_files}//g" \
  | sed "s/.txt//g" \
  | tr "\n" "\t" \
  > ${de_date}${target_files}david.table
sed -i 's/\t$/\n/' ${de_date}${target_files}david.table
# write table
paste $(ls ${de_dir}${de_date}${target_files}*.txt) \
  >> ${de_date}${target_files}david.table
