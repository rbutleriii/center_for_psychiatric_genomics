#!/usr/bin/env Rscript

library(data.table)
library(SuperExactTest)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/SST-SA_comparison/SST_overlaps'))

today = format(Sys.Date(), '%Y%m%d')
nameset = '_SST_overlaps_'

## Functions
# add gene lists from list files
add_set = function(genesets, files) {
  fl = lapply(files, readLines)
  setattr(fl, 'names', genesets)
  return(fl)
}

## Super exact testing for enrichment of ai genes
# SST
# make list
f_names = c("SST_Fnac", "SST_Fnash", "SST_Fvta", 
            "SST_Mnac", "SST_Mnash", "SST_Mvta")
sst_dir = paste0(rootdir, '/sensitization/dsq_split_DE_analysis')
target_files = "20200511_dsq_split_ultrawide_"
files = list.files(path=sst_dir, pattern=paste0(target_files, "*"), 
                   full.names=T)
sst_list = add_set(f_names, files)
bckgrnd = fread(paste0(rootdir, "/sensitization/dsq_split_DE_analysis/20200511_dsq_split_background.txt"))

# run test
res=supertest(sst_list, n=nrow(bckgrnd))
pdf(file=paste0(today, nameset, "SET_plot.pdf"), width=11, height=8.5)
plot(res, Layout="landscape", degree=2:6, sort.by="p-value", margin=c(0.5,5,1,2))
dev.off()
write.csv(summary(res)$Table, file=paste0(today, nameset, "summary.csv"), 
          row.names=FALSE)

