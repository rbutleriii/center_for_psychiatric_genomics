#!/usr/bin/env Rscript

library(UpSetR)

setwd('/data/butlerr/nicotine_sensi/SST-SA_comparison/Overlaps')
today = format(Sys.Date(), '%Y%m%d')
nameset = "_overlap_ultrawide"
sensi_dir = '/data/butlerr/nicotine_sensi/sensitization/dsq_split_DE_analysis'
self_dir = '/data/butlerr/nicotine_sensi/self_admin/dsq_split_dropvta_DE'

#####################################################
# fetch lists from directories
target_files = c(paste0(sensi_dir, "/20200203_dsq_split_l2fc_ultrawide_resFnac.txt"),
                 paste0(sensi_dir, "/20200203_dsq_split_l2fc_ultrawide_resFnash.txt"),
                 paste0(sensi_dir, "/20200203_dsq_split_l2fc_ultrawide_resFvta.txt"),
                 paste0(sensi_dir, "/20200203_dsq_split_l2fc_ultrawide_resMnac.txt"),
                 paste0(sensi_dir, "/20200203_dsq_split_l2fc_ultrawide_resMnash.txt"),
                 paste0(sensi_dir, "/20200203_dsq_split_l2fc_ultrawide_resMvta.txt"),
                 paste0(self_dir, "/20200203_dsq_split_l2fc_ultrawide_resAvBnac.txt"),
                 paste0(self_dir, "/20200203_dsq_split_l2fc_ultrawide_resAvBnash.txt"),
                 paste0(self_dir, "/20200203_dsq_split_l2fc_ultrawide_resAvBvta.txt")
                 )
filenames = c("Fnac", "Fnash", "Fvta", "Mnac", "Mnash", "Mvta", "AvBnac", 
              "AvBnash", "AvBvta")

# read in lists
file_objs = lapply(seq_along(filenames), function(i) {
  assign(filenames[i], scan(file=target_files[i], what="", sep="\n"), 
         inherits=T)
})

# running UpSet
pdf(file=paste0(today, nameset, ".pdf"), onefile=F, paper="USr", width=11, 
    height=8.5)
upset(fromList(mget(filenames)), nsets=12, nintersects=70, order.by="freq")
dev.off()

 