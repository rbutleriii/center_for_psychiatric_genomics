#!/usr/bin/env Rscript

library(ggplot2)
library(ggpubr)
library(data.table)
library(patchwork)

setwd('/data/butlerr/nicotine_sensi/SST-SA_comparison')
today = format(Sys.Date(), '%Y%m%d')
nameset = "_dsq_correlations_l2fc_"
sensi_dir = '/data/butlerr/nicotine_sensi/sensitization/dsq_split_DE_analysis'
self_dir = '/data/butlerr/nicotine_sensi/self_admin/dsq_split_dropvta_DE'

#####################################################
# fetch lists from directories
target_files = c(paste0(sensi_dir, "/20191211_dsq_split_DEgenes_resFnac.txt"),
                 paste0(sensi_dir, "/20191211_dsq_split_DEgenes_resFnash.txt"),
                 paste0(sensi_dir, "/20191211_dsq_split_DEgenes_resFvta.txt"),
                 paste0(sensi_dir, "/20191211_dsq_split_DEgenes_resMnac.txt"),
                 paste0(sensi_dir, "/20191211_dsq_split_DEgenes_resMnash.txt"),
                 paste0(sensi_dir, "/20191211_dsq_split_DEgenes_resMvta.txt"),
                 paste0(self_dir, "/20200129_dsq_split_DEgenes_resAvBnac.txt"),
                 paste0(self_dir, "/20200129_dsq_split_DEgenes_resAvBnash.txt"),
                 paste0(self_dir, "/20200129_dsq_split_DEgenes_resAvBvta.txt")
                 )
f_names = c("Fnac", "Fnash", "Fvta", "Mnac", "Mnash", "Mvta", "AvBnac",
            "AvBnash", "AvBvta")

#####################################################
# read in files
all(file.exists(target_files))
# reading in tables, combine and melt by GWAS
file_list = lapply(target_files, fread)
lapply(file_list, function(x) setorder(x, V1))
setattr(file_list, 'names', f_names)

# truncate lists
short_list = lapply(file_list, function(x) {
  x[, c("V1", "symbol", "log2FoldChange", "baseMean", "pvalue", "padj")]
})
colnames = c("log2FoldChange", "baseMean", "pvalue", "padj")

# join all sets
result = short_list[[1]]
for (i in head(seq_along(short_list), -1)) {
  result = merge(x=result, y=short_list[[i+1]], by=c("V1", "symbol"), all.x=T, 
                 suffixes=c("", paste0(".", f_names[i+1])))
}
setnames(result, colnames, paste0(colnames, ".", f_names[1]))

# correlation plot function
plot_corr = function (table, x, y, title=NULL) {
  ggscatter(table, x=x, y=y, add="reg.line", conf.int=T,
      add.params=list(color="blue", fill="lightgray")) + ggtitle(title) +
    geom_hline(yintercept=0, linetype="dashed", col='gray') +
    geom_vline(xintercept=0, linetype="dashed", col='gray') +
    stat_cor(method = "pearson", label.x = 2, label.y = 2)
}

# plotting graphs
pdf(file=paste0(today, nameset, "plots.pdf"), onefile=T, paper="USr",
    width=11, height=8.5)
plot_corr(result, "log2FoldChange.Mnac", "log2FoldChange.Fnac", "L2FC SST MvF NAc")
plot_corr(result, "log2FoldChange.Mnash", "log2FoldChange.Fnash", "L2FC SST MvF NAsh")
plot_corr(result, "log2FoldChange.Mvta", "log2FoldChange.Fvta", "L2FC SST MvF VTA")
plot_corr(result, "log2FoldChange.Mnac", "log2FoldChange.Mnash", "L2FC SST M NAc vs SST M NAsh")
plot_corr(result, "log2FoldChange.Mnac", "log2FoldChange.Mvta", "L2FC SST M NAc vs SST M VTA")
plot_corr(result, "log2FoldChange.Mnac", "log2FoldChange.AvBnac", "L2FC SST M NAc vs SA NAc")
plot_corr(result, "log2FoldChange.Mnac", "log2FoldChange.AvBnash", "L2FC SST M NAc vs SA NAsh")
plot_corr(result, "log2FoldChange.Mnac", "log2FoldChange.AvBvta", "L2FC SST M NAc vs SA VTA")
plot_corr(result, "log2FoldChange.Mnash", "log2FoldChange.Mvta", "L2FC SST M NAsh vs SST M VTA")
plot_corr(result, "log2FoldChange.Mnash", "log2FoldChange.AvBnac", "L2FC SST M NAsh vs SA NAc")
plot_corr(result, "log2FoldChange.Mnash", "log2FoldChange.AvBnash", "L2FC SST M NAsh vs SA NAsh")
plot_corr(result, "log2FoldChange.Mnash", "log2FoldChange.AvBvta", "L2FC SST M NAsh vs SA VTA")
plot_corr(result, "log2FoldChange.Mvta", "log2FoldChange.AvBnac", "L2FC SST M VTA vs SA NAc")
plot_corr(result, "log2FoldChange.Mvta", "log2FoldChange.AvBnash", "L2FC SST M VTA vs SA NAsh")
plot_corr(result, "log2FoldChange.Mvta", "log2FoldChange.AvBvta", "L2FC SST M VTA vs SA VTA")
plot_corr(result, "log2FoldChange.AvBnac", "log2FoldChange.AvBnash", "L2FC SA NAc vs SA NAsh")
plot_corr(result, "log2FoldChange.AvBnac", "log2FoldChange.AvBvta", "L2FC SA NAc vs SA VTA")
plot_corr(result, "log2FoldChange.AvBnash", "log2FoldChange.AvBvta", "L2FC SA NAsh vs SA NAvta")
dev.off()

