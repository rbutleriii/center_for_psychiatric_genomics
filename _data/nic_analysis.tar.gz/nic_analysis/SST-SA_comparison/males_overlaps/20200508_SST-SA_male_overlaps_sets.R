#!/usr/bin/env Rscript

library(data.table)
library(SuperExactTest)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/SST-SA_comparison/males_overlaps'))

today = format(Sys.Date(), '%Y%m%d')
nameset = '_SST-SA_male_overlaps_'

## Functions
# add gene lists from list files
add_set = function(genesets, files) {
  fl = lapply(files, readLines)
  setattr(fl, 'names', genesets)
  return(fl)
}

## Super exact testing for enrichment of ai genes
# make list
f_names = c("SST_Mnac", "SST_Mnash", "SST_Mvta", "SA_nac", "SA_nash", "SA_vta")
# SST males
sst_dir = paste0(rootdir, '/sensitization/dsq_split_DE_analysis')
target_files = "20200511_dsq_split_ultrawide_resM"
files = list.files(path=sst_dir, pattern=paste0(target_files, ".*"), 
                   full.names=T)
# SA males
sa_dir = paste0(rootdir, '/self_admin/dsq_split_dropvta_DE')
sa_files = "20200513_dsq_split_ultrawide_"
files = c(files, list.files(path=sa_dir, pattern=paste0(sa_files, ".*"), 
                            full.names=T))
overlap_list = add_set(f_names, files)

# generate background
bckgrnd = fread(paste0(rootdir, "/sensitization/dsq_split_DE_analysis/20200511_dsq_split_background.txt"))
bckgrnd2 = fread(paste0(rootdir, "/self_admin/dsq_split_dropvta_DE/20200513_dsq_split_background.txt"))
gl = unique(union(bckgrnd$ensembl_gene_id, bckgrnd2$ensembl_gene_id))
# run test
res=supertest(overlap_list, n=length(gl))
pdf(file=paste0(today, nameset, "SET_plot.pdf"), width=11, height=8.5)
plot(res, Layout="landscape", degree=2:6, sort.by="p-value", margin=c(0.5,5,1,2))
dev.off()
write.csv(summary(res)$Table, file=paste0(today, nameset, "summary.csv"), 
          row.names=FALSE)

