#!/usr/bin/env Rscript
library(ggplot2)
library(data.table)
library(patchwork)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/self_admin/david_split_DE'))

# file naming info
today = format(Sys.Date(), '%Y%m%d')
nameset = '_DE_l2fc_human_uw_david_'
target_files = "20200416_DE_l2fc_human_uw_david_"
tissue_list = c("AvBnac", "AvBnash", "AvBvta")

# read in files
files = list.files(pattern=paste0(target_files, "A.*txt"))
all(file.exists(files))
# reading in tables, combine and melt by GWAS
file_list = lapply(files, fread)
setattr(file_list, 'names', lapply(files, function(x) {
  x = gsub(target_files, "", x)
  x = gsub(".txt", "", x)
}))
file_data = rbindlist(file_list, use.names=T, idcol="Tissue")

# sort and log scale lists
setorder(file_data, Benjamini)
file_data[, LogBH := -log10(Benjamini) ]
file_data[, LogP := -log10(PValue) ]
# exclude UP_Keywords and UP_Seq_Feature
file_data = file_data[ !(Category %in% c("UP_KEYWORDS", "UP_SEQ_FEATURE")) ]
fwrite(file_data, file=paste0(today, nameset, "stats.txt"), sep="\t", quote=F)

# plot function
plot_bars = function (k) {
  short_list = file_data[ Tissue == k ]
  short_list = head(short_list, 30)
  gg = ggplot(short_list, aes(x=Term, y=LogBH, fill=Category)) + 
    geom_bar(stat="identity") + theme_classic() + 
    theme(axis.text.x=element_text(angle=45, hjust=1)) + 
    labs(y="-log10(BH corr. P-value)") + 
    geom_hline(yintercept=1.301, linetype="dashed", col='gray') +
    ggtitle(paste0("BH corrected P-values for ", k)) +
    scale_x_discrete(limits=short_list$Term, 
                     label=function(x) strtrim(x, 50))
  gb = ggplot(short_list, aes(x=Term, y=LogP, fill=Category)) + 
    geom_bar(stat="identity") + theme_classic() + 
    theme(axis.text.x=element_text(angle=45, hjust=1)) + 
    labs(y="-log10(P-value)") + 
    geom_hline(yintercept=1.301, linetype="dashed", col='gray') +
    ggtitle(paste0("P-values for ", k)) +
    scale_x_discrete(limits=short_list$Term, 
                     label=function(x) strtrim(x, 30))
  gc = ggplot(short_list, aes(x=Term, y=Count, fill=Category)) + 
    geom_bar(stat="identity") + theme_classic() + 
    theme(axis.text.x=element_text(angle=45, hjust=1)) + 
    labs(y="Gene Count") + 
    ggtitle(paste0("Gene Count Enriched in ", k)) +
    scale_x_discrete(limits=short_list$Term, 
                     label=function(x) strtrim(x, 30))
  layout = "
  AAAAAABB
  CCCCDDDD
  "
  gg + guide_area() + gb + gc + plot_layout(guides='collect', design=layout)
  # plot(gg)
}

# generate pdfs
pdf(file=paste0(today, nameset, "plots.pdf"), onefile=T, paper="USr",
    width=11, height=8.5)
lapply(tissue_list, function(k) plot_bars(k))
dev.off()
