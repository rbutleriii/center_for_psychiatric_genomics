#!/usr/bin/env Rscript

library(data.table)
library(biomaRt)

rootdir = '/data/butlerr/nicotine_sensi'
sensi_dir = '/sensitization/dsq_split_DE_analysis'
setwd(paste0(rootdir, '/self_admin/dsq_split_dropvta_DE'))
human_chr = '/data/butlerr/reference/gwas/ENSG_coord_biomaRt.GRCh38.txt'
today = format(Sys.Date(), '%Y%m%d')
nameset = "_SA_DEgene_"
file_tails = c("AvBnac", "AvBnash", "AvBvta", "Mnac", "Mnash", "Mvta")
# DE files
target_sa = "20200129_dsq_split_DEgenes_res"
target_sst = paste0(rootdir, sensi_dir, "/20191211_dsq_split_DEgenes_res")
# thresholded DE gene lists
de_sa = "20200513_dsq_split_ultrawide_res"
de_sst = paste0(rootdir, sensi_dir, "/20200511_dsq_split_ultrawide_res")
# human annotation lookups
mhlkup_sa = "20200513_dsq_split_human_M-Hlookup.txt"
mhlkup_sst = paste0(rootdir, sensi_dir, 
                    "/20200511_dsq_split_human_M-Hlookup.txt")
# gene_lists
liu_nic = paste0(rootdir, "/Liu_et_al_ensrog.txt")
walker_adin = paste0(rootdir, "/Walker_AdIn_ensrog.txt")
walker_sa = paste0(rootdir, "/Walker_SA_ensrog.txt")

#####################################################
# reading in tables, rename and merge
fl = c(
  lapply(file_tails[1:3], function(x) fread(file=paste0(target_sa, x, ".txt"))),
  lapply(file_tails[4:6], function(x) fread(file=paste0(target_sst, x, ".txt")))
)
lapply(seq(fl), function(x) {
  setnames(fl[[x]], "V1", "ensembl_id")
  fl[[x]][, c("lfcSE", "stat") := NULL]
})
sfx = paste0(".", file_tails)
sa_tbl = fl[[1]]
for (i in head(seq(fl), -1)) {
  sa_tbl = merge(sa_tbl, fl[[i+1]], all=T, by=c("ensembl_id", "symbol"), 
                 suffixes=sfx[i:(i+1)])
}
# # if odd number of lists, needs correction to final colnames
# oldnames = c("baseMean", "log2FoldChange", "pvalue")
# setnames(sa_tbl, oldnames, paste0(oldnames, sfx[[3]]))

# subset by DE genes
fl2 = c(
  lapply(file_tails[1:3], function(x) fread(paste0(de_sa, x, ".txt"), header=F)),
  lapply(file_tails[4:6], function(x) fread(paste0(de_sst, x, ".txt"), header=F))
)
fd2 = unique(rbindlist(fl2, use.names=T))
sa_tbl = subset(sa_tbl, ensembl_id %in% fd2$V1)

# add gene info
glist = lapply(c(mhlkup_sa, mhlkup_sst), fread)
ginfo = unique(rbindlist(glist, use.names=T))
setnames(ginfo, c("ensembl_gene_id",
                  "chromosome_name", 
                  "start_position", 
                  "end_position", 
                  "hsapiens_homolog_ensembl_gene", 
                  "hsapiens_homolog_associated_gene_name"),
         c("ensembl_id",
           "chr", 
           "start", 
           "stop", 
           "hsapiens_ensembl_id", 
           "hsapiens_symbol"))
# add human chr info
# fetch from biomaRt
human = useEnsembl("ensembl", dataset="hsapiens_gene_ensembl", version="99")
lookups = ginfo$hsapiens_ensembl_id[ ginfo$hsapiens_ensembl_id != "" ]
hinfo = data.table(getBM(mart=human, filters="ensembl_gene_id", values=lookups,
                         attributes=c("ensembl_gene_id", "chromosome_name")))
setnames(hinfo, c("hsapiens_ensembl_id", "hsapiens_chr"))
ginfo = merge(ginfo, hinfo, all.x=T, sort=F, by="hsapiens_ensembl_id")

# merge with DE
sa_tbl = merge(ginfo, sa_tbl, all.y=T, by="ensembl_id")

# add gene lists they are in (Liu, Walker x2)
add_set = function(genefile, dest_tbl) {
  a = fread(genefile)
  list = unique(a$sets)
  for (i in seq(list)) {
    dest_tbl[, list[[i]] := if(ensembl_id %in% a[sets == list[[i]], 
        rnorvegicus_homolog_ensembl_gene]) 1 else 0, seq_len(nrow(dest_tbl))]
  }
}
add_set(liu_nic, sa_tbl)
add_set(walker_adin, sa_tbl)
add_set(walker_sa, sa_tbl)

# collapse duplicate rows from one to many homologies
mycols = names(sa_tbl)[!(like(names(sa_tbl), "hsapiens"))]
sa_tbl = sa_tbl[, lapply(.SD, function(x) toString(unique(x))), by=mycols]
sa_tbl[ hsapiens_chr == "NA", hsapiens_chr := "" ]

# reorder and save
setcolorder(sa_tbl, c("ensembl_id", "chr", "start", "stop", "symbol", 
                      "hsapiens_ensembl_id", "hsapiens_chr", "hsapiens_symbol", 
                      "baseMean.AvBnac", "log2FoldChange.AvBnac", 
                      "pvalue.AvBnac", "padj.AvBnac", "baseMean.AvBnash", 
                      "log2FoldChange.AvBnash", "pvalue.AvBnash", "padj.AvBnash", 
                      "baseMean.AvBvta", "log2FoldChange.AvBvta", 
                      "pvalue.AvBvta", "padj.AvBvta", "baseMean.Mnac", 
                      "log2FoldChange.Mnac", "pvalue.Mnac", "padj.Mnac", 
                      "baseMean.Mnash", "log2FoldChange.Mnash", "pvalue.Mnash", 
                      "padj.Mnash", "baseMean.Mvta", "log2FoldChange.Mvta", 
                      "pvalue.Mvta", "padj.Mvta", "AOI", "CPD", "SCe", "SIn", "DPW", 
                      "Walker_AdIn_Pos_Nac", "Walker_AdIn_Neg_Nac", 
                      "Walker_AdIn_Pos_VTA", "Walker_AdIn_Neg_VTA", 
                      "Walker_SA_Up_Nac", "Walker_SA_Down_Nac", 
                      "Walker_SA_Up_VTA", "Walker_SA_Down_VTA"))
fwrite(sa_tbl, file=paste0(today, nameset, "annotation_tbl.txt"), sep="\t", quote=F)
