#!/usr/bin/env Rscript

library(data.table)
library(GeneOverlap)
library(stringr)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/self_admin/dsq_split_dropvta_DE'))

today = format(Sys.Date(), '%Y%m%d')
nameset = '_SA_gene_enrichment_'

##################################FUNCTIONS
# function runs enrichment and saves to file for p and padj
# takes two set lists, background gene count and output name and pdf width
enrich = function(list1, list2, background, outname, width=7) {
  # enrichment basic
  gom.obj = newGOM(list1, list2, background)
  # write pvals to file
  a = getMatrix(gom.obj, name="pval")
  write.csv(a, file=paste0(today, nameset, outname, ".txt"))
  b = matrix(p.adjust(a, method="BH"), nrow=nrow(a), dimnames=dimnames(a))
  write.csv(b, file=paste0(today, nameset, outname, "_padj.txt"))
  # plot heatmaps
  pdf(file=paste0(today, nameset, outname, ".pdf"), width=width)
  drawHeatmap(gom.obj, grid.col="Blues", cutoff=0.1)
  dev.off()
  pdf(file=paste0(today, nameset, outname, "_padj.pdf"), width=width)
  drawHeatmap(gom.obj, grid.col="Blues", adj.p=T, cutoff=0.1)
  dev.off()
}

# add gene lists from list files
add_set = function(genesets, files) {
  fl = lapply(files, readLines)
  setattr(fl, 'names', genesets)
  return(fl)
}

# add gene lists from table file
add_tbl = function(genefile) {
  dt = fread(genefile)
  list = unique(dt$sets)
  a = list()
  for (i in seq(list)) {
    a[[list[i]]] = dt[sets == list[i], rnorvegicus_homolog_ensembl_gene]
  }
  return(a)
}

##################################MAIN
## Fisher exact testing for enrichment of ai genes
# for SA genes, X chromosome genes, Liu et al, Walker et al genes

# backgrounds: overall gene list and SST expressed genes
# all
all_genes = fread("/data/butlerr/nicotine_sensi/self_admin/allelic_imbalance/prop_test/ENSRNOG_coord_biomaRt.Rnor6.txt")
setnames(all_genes, c("ensembl_id", "chr", "start", "stop", "strand", "biotype"))
gs_all = nrow(all_genes)
#expressed
gs_sa = nrow(fread("20200513_dsq_split_background.txt"))

# SA
# make list
f_names = c("SA_up_nac", "SA_up_nash", "SA_up_vta", "SA_down_nac", 
            "SA_down_nash", "SA_down_vta")
# up
sa_dir = paste0(rootdir, '/self_admin/dsq_split_dropvta_upgenes/')
target_files = "20200513_dsq_split_up_ultrawide_"
files = list.files(path=sa_dir, pattern=paste0(target_files, "*"), 
                   full.names=T)
# down
sa_dir2 = paste0(rootdir, '/self_admin/dsq_split_dropvta_downgenes/')
target_files2 = "20200513_dsq_split_down_ultrawide_"
files = c(files, list.files(path=sa_dir2, pattern=paste0(target_files2, "*"), 
                            full.names=T))
sa_list = add_set(f_names, files)

# CHR
# make chr list
chr_list = list()
for (k in as.character(seq(20))) {
  chr_list[[k]] = all_genes[chr == k, ensembl_id]
}
enrich(sa_list, chr_list, gs_all, "1-20", 20)

# X
# make X list
XY_list = list("X"=all_genes[chr == "X", ensembl_id],
               "Y"=all_genes[chr == "Y", ensembl_id])
enrich(sa_list, XY_list, gs_all, "XY")

# Liu etal
# make list
nic_list = add_tbl("/data/butlerr/nicotine_sensi/Liu_et_al_ensrog.txt")
enrich(sa_list, nic_list, gs_all, "Liu", 8)

# Walker etal SA genes
# make list
walk_sa_list = add_tbl("/data/butlerr/nicotine_sensi/Walker_SA_ensrog.txt")
enrich(sa_list, walk_sa_list, gs_sa, "Walker_SA")

# Walker etal AdIndex genes
# make list
walk_adin_list = add_tbl("/data/butlerr/nicotine_sensi/Walker_AdIn_ensrog.txt")
enrich(sa_list, walk_adin_list, gs_sa, "Walker_AdIn")

