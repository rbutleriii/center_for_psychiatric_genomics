#!/usr/bin/env Rscript

# dsq
library(DESeq2)
library(BiocParallel)
library(RColorBrewer)
library(data.table)
library(magrittr)
# plotting
library(ggplot2)
library(ggrepel)
library(gridExtra)
library(EnhancedVolcano)
# sva
library(sva)
library(GGally)


register(MulticoreParam(30))
# directory locations
rootdir = '/data/butlerr/nicotine_sensi/self_admin'
setwd(paste0(rootdir, '/dsq_split_dropvta_DE'))
# file naming info
today = format(Sys.Date(), '%Y%m%d')
nameset = '_dsq_split_'
# don't forget to define pca functions at the bottom
# Deseq dataset to run from
load(paste0(rootdir, '/dsq_broad_analysis/20191004_salmon_Dsq2_dds.Rdata'))

#################################
# DE analysis per individual group
# switch to  A / B for self_admin vs non-self_admin test
dds$f1_cross %<>% relevel("B")

# dropping contaminated data point & duplicate
exclude_list <- c("2_1_box2")
dds <- dds[ , !(colnames(dds) %in% exclude_list) ]

# model without tissue, self_admin, or SV included, 
# covariate SST for batch correction
design(dds) = ~ trt + f1_cross

# results for each tissue type
sensitization = function (tissue) {
  # subset by tissue and sex
  dds1 = dds[ , (dds$tissue == tissue) ]
  colData(dds1) = droplevels(colData(dds1))
  # filter low count genes (n of smallest group is 3)
  dds1 = dds1[ rowSums( counts(dds1, normalized=T) >= 10 ) >= 3, ]
  print(paste(nrow(dds1), "filtered genes in ", tissue))
  # run analysis
  dds1 = DESeq(dds1, parallel=T)
  metadata(dds1) = metadata(dds1)[1]
  # condition effect (AvB exposure)
  print(paste0("resAvB", tissue))
  x = results(dds1, parallel=T)
  assign(paste0("resAvB", tissue), x , inherits=T)
  # w/ shrinkage
  print(paste0("resshAvB", tissue))
  assign(paste0("resshAvB", tissue), 
         lfcShrink(dds1, coef="f1_cross_A_vs_B", type="apeglm", parallel=T), 
         inherits=T)
}

# run the function
sensitization("vta")
sensitization("nac")
sensitization("nash")

# sort for list operations
result_list = mget(c(rbind(sort(ls(pattern="^res[^su]")),
                           sort(ls(pattern="^ress")))))
result_names = c(rbind(sort(ls(pattern="^res[^su]")),
                       sort(ls(pattern="^ress"))))

# annotate genes
result_list <- lapply(result_list, function(x) {
  x$symbol <- mcols(dds)$symbol[match(rownames(x), rownames(dds))]
  x
})

# write results to file
lapply(seq_along(result_list), function(x) {
  df1 <- as.data.frame(result_list[[x]])
  tab_name <- result_names[[x]]
  # order by l2fc
  df1 <- df1[ order(-df1$log2FoldChange), ]
  # write it
  f1 <- paste0(today, nameset, "DEgenes_", tab_name, ".txt")
  write.table(df1, sep = "\t", quote = F, col.names = NA, file = f1)
  # write ultra-wide list (alpha < 0.05)
  uwide_genes = rownames(df1)[ !is.na(df1$pvalue) & (df1$pvalue < 0.05)]
  f2 = paste0(today, nameset, "ultrawide_genes_", tab_name, ".txt")
  fwrite(list(uwide_genes), quote=F, col.names=F, file=f2)
  # write wide list (alpha < 0.005)
  wide_genes = rownames(df1)[ !is.na(df1$pvalue) & (df1$pvalue < 0.005)]
  f3 = paste0(today, nameset, "wide_genes_", tab_name, ".txt")
  fwrite(list(wide_genes), quote=F, col.names=F, file=f3)
  # write narrow list (padj < 0.1)
  narrow_genes = rownames(df1)[ !is.na(df1$padj) & (df1$padj < 0.1)]
  f4 = paste0(today, nameset, "narrow_genes_", tab_name, ".txt")
  fwrite(list(narrow_genes), quote=F, col.names=F, file=f4)
})

# making background geneset
background <- as.data.frame(mcols(dds)$symbol)
rownames(background) <- rownames(dds)

# write it
f1 <- paste0(today, nameset, "DEgenes_background.txt")
write.table(background, sep="\t", quote=F, row.names=T, col.names=NA, file=f1)


##################################
# MA plots
plot_list <- lapply(seq_along(result_list), function(x) {
  df1 <- as.data.frame(result_list[[x]])
  # limit to pval subset
  df1 <- df1[ !is.na(df1$pvalue) & df1$pvalue <= 0.15, ]
  # assign gene symbols
  tab_name <- result_names[[x]]
  # curb large values to edge of graph
  df1$log2FoldChange[ df1$log2FoldChange > 3 ] <- 3
  df1$log2FoldChange[ df1$log2FoldChange < -3 ] <- -3
  df1$shape <- ifelse(abs(df1$log2FoldChange) < 3, 1,
                      ifelse(sign(df1$log2FoldChange) >= 0, 2, 3))
  # define genes to be labeled as topGene
  topGene <- df1$symbol[ (abs(df1$log2FoldChange) > 1) & (!is.na(df1$padj))
                        & (df1$padj < 0.15) & (df1$baseMean > 5) ]
  # plot
  gg <- ggplot(df1, aes(x=baseMean, y=log2FoldChange, label=symbol)) +
    labs(x="Mean of normalized counts", y="Log fold change", title=tab_name) +
    geom_point(col=ifelse(is.na(df1$padj), "cyan", 
                          ifelse(df1$padj < 0.1 , "red", "grey")), 
               aes(shape=as.factor(shape))) +
    scale_x_log10() + 
    ylim(-3,3) + 
    geom_hline(yintercept=-1:1, col="dodgerblue", lwd=0.5, linetype = "dashed") +
    geom_text_repel(data=subset(df1, symbol %in% topGene), col="#444444") + 
    scale_shape_manual(guide=F, values=c(16, 2, 6)) +
    theme_classic()
})

# printing 
ml <- marrangeGrob(plot_list, nrow=3, ncol=2, respect = T, 
                   layout_matrix = cbind(c(1, 3, 5), c(2,4,6)))
ggsave(paste0(today, nameset, "MAplots.pdf"), ml, width = 8.5, height = 11, 
       useDingbats=F)


##################################
# Volcano plots
volc_list <- lapply(seq_along(result_list), function(x) {
  df1 <- as.data.frame(result_list[[x]])
  # limit to pval subset
  df1 <- df1[ !is.na(df1$pvalue), ]
  # assign gene symbols
  tab_name <- result_names[[x]]
  # plot
  EnhancedVolcano(df1, lab=df1$symbol, x='log2FoldChange', y='pvalue', 
                  legendVisible=F, title=tab_name, subtitle=F, pCutoff=0.05)
})
ml <- marrangeGrob(volc_list, nrow=1, ncol=1)
ggsave(paste0(today, nameset, "Volcanos.pdf"), ml, width = 8.5, height = 11, 
       useDingbats=F)

