#!/usr/bin/env Rscript

library(data.table)

a = fread("AB_samples.txt")
f1 = c("A", "B")
tiss = c("nac", "nash", "vta")

for (x in f1) {
  for (y in tiss) {
    out = paste0("A_B_masked_bams/", a[f1_cross == x & tissue == y, run], 
                 "Aligned.splitN.bam")
    fwrite(list(out), file=paste0(x, y, ".group"), quote=F, col.names=F)
  }
}

