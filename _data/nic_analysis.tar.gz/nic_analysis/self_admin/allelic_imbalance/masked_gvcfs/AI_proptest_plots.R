#!/usr/bin/env Rscript

library(ggplot2)
library(ggpubr)
library(ggrepel)
library(data.table)
library(qqman)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/self_admin/allelic_imbalance/masked_gvcfs'))

today = format(Sys.Date(), '%Y%m%d')
nameset = '_AI_volcano_'
nameset2 = '_AI_manhattan'
nameset3 = '_AI_snp_counts'

####FUNCTIONS
# plot function
plot_bars = function (k, titl, grp) {
  fdr = paste0(grp, "_binomFDR")
  frac = paste0(grp, "REF_FRAC")
  # rounding issues with P less than 2.225074e-308
  k[[fdr]][ k[[fdr]] <= 1e-200 ] = 1e-200
  ggAD = ggplot(k, aes(x=get(frac), y=-log10(get(fdr)), label=SNP)) + 
                geom_point(color="navy") + ggtitle(paste0("Chromosome ", titl)) + 
                guides(color=F) + ylim(c(0,200)) + theme_classic() +
                geom_text_repel(data=subset(k, -log10(get(fdr)) > 100)) +
                xlab(frac) + ylab(paste0("-log ", fdr))
}

# plot by chromosomes
plot_chr = function (k, titl, grp) {
  use_chr = c(1:22, "X", "Y")
  plot_list = lapply(use_chr, function(x) plot_bars(k[ CHR == x ], x, grp))
  ml = ggarrange(plotlist=plot_list, nrow=2, ncol=3)
  annotate_figure(ml, top=text_grob(titl, color="black", face="bold", size=14))
  return(ml)
}

# manhattan function
plot_man = function (k, titl, grp) {
  fdr = paste0(grp, "_binomFDR")
  k_num = k
  k_num$CHR[ k_num$CHR == "X" ] = "23"
  k_num$CHR[ k_num$CHR == "Y" ] = "24"
  k_num$CHR[ k_num$CHR == "MT" ] = "25"
  k_num[, CHR := as.integer(CHR) ]
  # rounding issues with P less than 2.225074e-308
  k_num[[fdr]][ k_num[[fdr]] <= 1e-200 ] = 1e-200
  manhattan(k_num, p=fdr, annotatePval=1e-100, annotateTop=F, main=titl, 
            ylab=paste0("-log ", fdr), ylim=c(0,205), col=c("blue4", "orange3"))
}

####MAIN
# read in files
files = list.files(pattern=".*output.plot")
all(file.exists(files))

# groups for binning
sT = fread(paste0(rootdir, "/self_admin/20190815_sampleTable.txt"))
sT = sT[ self_admin == "nic" & name != "2_1_box2"]

for (x in files) {
  xname = sub("_output.plot", "", x)
  a = fread(x)
  all = sT[tissue == xname, run]
  a_grp = sT[tissue == xname & f1_cross == "A", run]
  b_grp = sT[tissue == xname & f1_cross == "B", run]
  # Rename and cleanup
  heads = names(a)
  heads = gsub("# ", "", heads)
  heads = gsub("\\[\\d{1,2}\\]", "", heads)
  setnames(a, heads)
  setnames(a, c("CHROM", "POS", "REF", "ALT", "ID"),
              c("CHR", "BP", "REF", "ALT", "SNP"))
  # remove indels, multiallelics
  a = a[ nchar(REF) == 1 & nchar(ALT) == 1 ]
  # add IDs for no rsnum
  a[ SNP == "." , SNP := paste(CHR, BP, REF, ALT, sep="_") ]
  # generate individual depth metrics
  lapply(all, function(k) {
    a[, c(paste0(k,":REFDP"), paste0(k,":ALTDP")) 
        := tstrsplit(a[[paste0(k, ":AD")]], ",", type.convert=T, fixed=T)]
    # drop unnecessary columns
    a[, c(paste0(k, ":AD")) := NULL ]
  })
  # convert columns to integers
  deps = paste0(all, ":DP")
  a[, (deps) := lapply(.SD, function(x) gsub("\\.", "0", x)), .SDcols=deps]
  a[, (deps) := lapply(.SD, as.integer), .SDcols=deps]
  # quality filtering (all DP columns >= 20)
  a = a[a[, Reduce(`&`, lapply(.SD, `>=`, 20)), .SDcols = deps]]
  # quality filtering Ref/Alt SNP >=2 in at least three samples (smallest n)
  refdps = paste0(all, ":REFDP")
  altdps = paste0(all, ":ALTDP")
  a = a[a[, rowSums(.SD >= 2) >= 3, .SDcols=refdps]]
  a = a[a[, rowSums(.SD >= 2) >= 3, .SDcols=altdps]]
  # generate aggregate counts
  a[, AREFDP := sum(.SD), seq_len(nrow(a)), .SDcols=paste0(a_grp, ":REFDP") ]
  a[, AALTDP := sum(.SD), seq_len(nrow(a)), .SDcols=paste0(a_grp, ":ALTDP") ]
  a[, ADP := sum(.SD), seq_len(nrow(a)), .SDcols=paste0(a_grp, ":DP") ]
  a[, AREF_FRAC := AREFDP / ADP ]
  a[, BREFDP := sum(.SD), seq_len(nrow(a)), .SDcols=paste0(b_grp, ":REFDP") ]
  a[, BALTDP := sum(.SD), seq_len(nrow(a)), .SDcols=paste0(b_grp, ":ALTDP") ]
  a[, BDP := sum(.SD), seq_len(nrow(a)), .SDcols=paste0(b_grp, ":DP") ]
  a[, BREF_FRAC := BREFDP / BDP ]
  a[, "AFRAC-BFRAC" := AREF_FRAC - BREF_FRAC ]
  # binomial test for AI of snps
  a[, A_binomP := binom.test(x=AREFDP, n=ADP)$p.value, seq_len(nrow(a))]
  a[, A_binomFDR := p.adjust(A_binomP, method="fdr") ]
  a[, B_binomP := binom.test(x=BREFDP, n=BDP)$p.value, seq_len(nrow(a))]
  a[, B_binomFDR := p.adjust(B_binomP, method="fdr") ]
  
  # plot
  ggexport(filename=paste0(xname, nameset, "A.pdf"), 
           plotlist=plot_chr(a, xname, "A"), width=11, height=8.5)
  ggexport(filename=paste0(xname, nameset, "B.pdf"), 
           plotlist=plot_chr(a, xname, "B"), width=11, height=8.5)
  pdf(file=paste0(xname, nameset2, ".pdf"), onefile=T, paper="USr",
      width=11, height=8.5)
  plot_man(a, xname, "A")
  plot_man(a, xname, "B")
  dev.off()
  fwrite(a, file=paste0(xname, nameset3, ".txt"), sep="\t", quote=F)
}


####Notes
# head *sample.counts
# ==> nac_output.sample.counts <==
 # 114548 11-2_box_2_S64
  # 98838 1-2_box_2_S46
 # 107378 13-2_box_2_S67
 # 111230 15-2_box_2_S70
 # 110947 16-2_box_2_S72
 # 109544 2-2_box_2_S48
 # 104490 3-2_box_2_S51
 # 111161 4-2_box_2_S54

# ==> nash_output.sample.counts <==
 # 113688 11-3_box_2_S65
 # 110354 13-3_box_2_S68
 # 116404 1-3_box_2_S47
 # 113966 15-3_box_2_S71
 # 111109 16-3_box_2_S73
 # 112688 2-3_box_2_S49
 # 117024 3-3_box_2_S52
 # 113225 4-3_box_2_S55

# ==> vta_output.sample.counts <==
 # 119364 11-1_box_2_S63
 # 118672 1-1_box_2_S45
 # 109336 13-1_box_2_S66
 # 137570 15-1_box_2_S69
 # 111967 16-1_box2_S123
 # 104685 3-1_box_2_S50
 # 109500 4-1_box_2_S53

 # wc -l *snp_counts*txt
   # 7336 nac_AI_snp_counts.txt
   # 8129 nash_AI_snp_counts.txt
   # 8420 vta_AI_snp_counts.txt


