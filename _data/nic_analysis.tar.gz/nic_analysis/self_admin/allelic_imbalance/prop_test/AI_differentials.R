#!/usr/bin/env Rscript

library(data.table)
# plot
library(ggplot2)
library(ggpubr)
library(ggrepel)


# directory locations
rootdir = '/data/butlerr/nicotine_sensi/self_admin/allelic_imbalance'
setwd(paste0(rootdir, '/prop_test'))

# variables
today = format(Sys.Date(), '%Y%m%d')
nameset = '_AI_proptest_'
tiss = c("nac", "nash", "vta")
fdr = 0.05
frac_diff = 0.1

## functions
# filter function accepts a, fdr, frac_diff returns d and count as list
filter_func = function(dt=a, fd=fdr, fr=frac_diff) {
  # filter based on binom test
  b = dt[ A_binomFDR < fd | B_binomFDR < fd ]
  # 2 proportion test for difference of A vs B
  b[, P := prop.test(c(AREFDP, BREFDP), c(ADP, BDP))$p.value, seq_len(nrow(b))]
  b[, FDR := p.adjust(P, method="fdr") ]
  # filter by prop test fdr
  c = b[ FDR < fd ]
  # filter by `AFRAC-BFRAC` abs greater than frac_diff
  d = c[ abs(`AFRAC-BFRAC`) > fr ]
  count = rbindlist(list(dt[, .(NAME="raw", .N), by=GROUP],
                         b[, .(NAME="binom", .N), by=GROUP],
                         c[, .(NAME="prop", .N), by=GROUP],
                         d[, .(NAME="frac_diff", .N), by=GROUP]))
  return(list(d, count))
}

# plot function
plot_scatter = function (k, titl) {
  ggAD = ggplot(k, aes(x=BREF_FRAC, y=AREF_FRAC, label=SNP)) + 
                geom_point(color="navy") + ggtitle(titl) + guides(color=F) + 
                geom_hline(yintercept=0.5, linetype="dashed", col='darkgray') +
                geom_vline(xintercept=0.5, linetype="dashed", col='darkgray') +
                geom_text_repel(data=subset(k, -log10(FDR) > 150))
}

# plot loop function aggregates data
plot_bars = function (dt) {
  ggAD = ggplot(dt, aes(x=GROUP, y=N, fill=CUTOFF)) +
    geom_bar(stat="identity", position=position_dodge()) +
    scale_color_brewer(type="qual", palette="Set2") +
    ggtitle(paste0("Cutoffs for Allelic Imbalance")) +
    labs(x="tissues", y="num of genes", fill="fdr|frac_diff") +
    theme_classic() + theme(axis.text.x=element_text(angle=45, hjust=1))
}

## main
# read in files
files = paste0(rootdir, "/masked_gvcfs/", tiss, "_AI_snp_counts.txt")
all(file.exists(files))

# reading in tables, combine and melt by GWAS
file_list = lapply(files, fread)
setattr(file_list, 'names', tiss)
lapply(file_list, function(x){
  x[, grep(":\\w{0,3}DP$", colnames(x), perl=T) := NULL]
})
file_data = rbindlist(file_list, use.names=T, idcol="GROUP")

# filter out X chr ref frac diff -0.9<x<0.9 (haploid positions)
x = file_data[ CHR=="X" & (`AFRAC-BFRAC` < -0.9 | `AFRAC-BFRAC` > 0.9), ]
fwrite(x, file=paste0(today, nameset, "XnonPAR.txt"), sep="\t", quote=F)
a = file_data[!(CHR=="X" & (`AFRAC-BFRAC` < -0.9 | `AFRAC-BFRAC` > 0.9))]

# loop of filters to get scatter and bar plots of final counts
fd_list = c(rep(0.1, 4), rep(0.05, 4), rep(0.01, 4))
fr_list = rep(c(0.05, 0.1, 0.15, 0.2), 3)
looper = mapply(filter_func, fd_list, fr_list, MoreArgs=list(dt=a), SIMPLIFY=F)
plot_loop = lapply(seq_along(looper), function(i) {
  dt = looper[[i]][[1]]
  lapply(tiss, function(x) {
    plot_scatter(dt[ GROUP == x ], 
      paste("Tissue:", x, "  FDR:", fd_list[[i]], "  frac_diff:", fr_list[[i]]))
  })
})
ggexport(filename=paste0(today, nameset, "loop_scatter.pdf"), 
         plotlist=unlist(plot_loop, recursive=F), nrow=12, ncol=3, width=12, height=48)
# barplot
myna = paste0(fd_list, "|", fr_list)
loop_count = rbindlist(lapply(setNames(seq_along(looper),myna), function(i) {
  looper[[i]][[2]][NAME == "frac_diff"]
}), use.names=T, idcol="CUTOFF")
ggsave(filename=paste0(today, nameset, "loop_cutoffs.pdf"), 
       plot=plot_bars(loop_count), width=11, height=8.5)



# final output
out = filter_func(a)

# plot bias by tissue
plot_list = lapply(tiss, function(x) plot_scatter(out[[1]][ GROUP == x ], 
    paste("Tissue:", x, "  FDR:", fdr, "  frac_diff:", frac_diff)))
ggexport(filename=paste0(today, nameset, fdr, "fdr_", frac_diff, "diff_scatter.pdf"), 
         plotlist=plot_list, nrow=1, ncol=3, width=12, height=4)

# write snps
fwrite(out[[1]], file=paste0(today, nameset, fdr, "fdr_", frac_diff, "diff_snps.txt"), 
       sep="\t", quote=F)

# write filtered counts
fwrite(out[[2]], file=paste0(today, nameset, fdr, "fdr_", frac_diff, "diff_counts.txt"), 
       sep="\t", quote=F)

