#!/usr/bin/env Rscript

library(data.table)
library(stringr)
library(VennDiagram)
library(GeneOverlap)
library(biomaRt)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/self_admin/allelic_imbalance/prop_test'))

today = format(Sys.Date(), '%Y%m%d')
nameset = '_AI_overlap_genes_'

rat = useEnsembl("ensembl", dataset="rnorvegicus_gene_ensembl", version="99")
human = useEnsembl("ensembl", dataset="hsapiens_gene_ensembl", version="99")

## AI GENE ANNOTATIONS
# read in gene annotation files
files = list.files(pattern="*.genes.annot$")
names = gsub('.genes.annot', '', files)

# reading in AI tables, combine and melt by GWAS
file_list = lapply(files, function(x) {
  a = fread(x, header=F, sep=',', skip='ENS')
  # fread fails at column detection, generate counts and split rows
  a[, COUNT := str_count(V1, '\t')-1 ]
  a[, COUNT := str_count(V1, '\t')-1 ]
  a[, c(paste0("V", 3:(max(a$COUNT) + 4))) := tstrsplit(V1, '\t', fill=NA)]
  # collapse snps into a single column
  snpcols = names(a)[5:length(a)]
  a[, snps := paste0(.SD, collapse=","), seq(nrow(a)), .SDcols=snpcols]
  a[, snps := gsub(",NA", "", snps)]
  # return counts
  b = a[, c("V3", "V4", "COUNT", "snps")]
  setnames(b, c("ensembl_id", "position", "count", "snps"))
  return(b)
})
setattr(file_list, 'names', names)
ai_gene = rbindlist(file_list, use.names=T, idcol="file")
ai_gene[, c("tissue", "a", "b", "bias", "c") := tstrsplit(file, '_') ]
ai_gene[, c("b", "a", "c", "file", "position") := NULL ] # add pposition

# check intersections for ref and alt to detect genes with one of each snp bias
tiss = c("nac", "nash", "vta")
bias = c("Inc", "Dec")

# venns of overlaps(svg)
lapply(tiss, function(k) {
  venn.plot = venn.diagram(x=list(
      "Inc"=ai_gene[tissue == k & bias == "Inc", ensembl_id],
      "Dec"=ai_gene[tissue == k & bias == "Dec", ensembl_id]),
    filename=paste0(today, nameset, k, "_gene_venn.svg"), imagetype="svg", 
    main=paste0("Genes with allelic imbalance in ", k), main.cex=1.5)
})

# venns of overlaps(png)
lapply(tiss, function(k) {
  venn.plot = venn.diagram(x=list(
      "Inc"=ai_gene[tissue == k & bias == "Inc", ensembl_id],
      "Dec"=ai_gene[tissue == k & bias == "Dec", ensembl_id]),
    filename=paste0(today, nameset, k, "_gene_venn.png"), imagetype="png", 
    main=paste0("Genes with allelic imbalance in ", k), main.cex=1.5)
})

# add gene info
ginfo = data.table(getBM(mart=rat, filters="ensembl_gene_id", 
                         values=ai_gene$ensembl_id,
                         attributes=c("ensembl_gene_id", "external_gene_name", 
                                      "chromosome_name", "start_position", 
                                      "end_position", 
                                      "hsapiens_homolog_ensembl_gene", 
                                      "hsapiens_homolog_associated_gene_name")))
setnames(ginfo, c("ensembl_gene_id", "external_gene_name", "chromosome_name", 
                  "start_position", "end_position", 
                  "hsapiens_homolog_ensembl_gene", 
                  "hsapiens_homolog_associated_gene_name"),
         c("ensembl_id", "symbol", "chr", "start", "stop", 
           "hsapiens_ensembl_id", "hsapiens_symbol"))
# add human chr info
# fetch from biomaRt
lookups = ginfo$hsapiens_ensembl_id[ ginfo$hsapiens_ensembl_id != "" ]
hinfo = data.table(getBM(mart=human, filters="ensembl_gene_id", values=lookups,
                         attributes=c("ensembl_gene_id", "chromosome_name")))
setnames(hinfo, c("hsapiens_ensembl_id", "hsapiens_chr"))
ginfo = merge(ginfo, hinfo, all.x=T, sort=F, by="hsapiens_ensembl_id")

# merge with DE
ai_gene = merge(ginfo, ai_gene, all.y=T, by="ensembl_id", allow.cartesian=T)

# collapse duplicate rows from one to many homologies
mycols = names(ai_gene)[!(like(names(ai_gene), "hsapiens"))]
ai_gene = ai_gene[, lapply(.SD, function(x) toString(unique(x))), by=mycols]
ai_gene[ hsapiens_chr == "NA", hsapiens_chr := "" ]


## AI SNP ANNOTATIONS
# read in SNP annotation file
ai_snp = fread("20200808_AI_proptest_0.05fdr_0.1diff_snps.txt")
# build a snp to gene list using ai_gene
genelist = list()
for (i in seq(ai_gene$ensembl_id)) {
  b = unlist(strsplit(ai_gene$snps[[i]], ','))
  for (j in b) genelist[[j]] = c(genelist[[j]], ai_gene$ensembl_id[[i]])
}
# build a snp to gene symbol list using ai_gene
symbolist = list()
for (i in seq(ai_gene$symbol)) {
  b = unlist(strsplit(ai_gene$snps[[i]], ','))
  for (j in b) symbolist[[j]] = c(symbolist[[j]], ai_gene$symbol[[i]])
}
# annotate with gene and symbol information
ai_snp[, GENE := paste0(unique(genelist[[SNP]]), collapse=","), 
       seq(nrow(ai_snp))]
ai_snp[, SYMBOL := paste0(unique(symbolist[[SNP]]), collapse=","), 
       seq(nrow(ai_snp))]
# explode snp list for rows with mulitple genes
b = data.table(ensembl_id=character(), AREF_FRAC=numeric(), BREF_FRAC=numeric(), 
               FDR=numeric(), tissue=character())
for (x in seq(nrow(ai_snp))) {
  a = unlist(strsplit(ai_snp[x][["GENE"]], ","))
  for (i in a) {
    b = rbind(b, list(i, ai_snp[x][["AREF_FRAC"]], ai_snp[x][["BREF_FRAC"]], 
                      ai_snp[x][["FDR"]], ai_snp[x][["GROUP"]]))
  }
}

# add ai_snp meanAREF_FRAC, meanBREF_FRAC, meanFDR to ai_gene
ai_mean = b[, .("meanAREF_FRAC"=mean(AREF_FRAC), "meanBREF_FRAC"=mean(BREF_FRAC), 
    "meanREF_FRACdiff"=(mean(AREF_FRAC) - mean(BREF_FRAC)), "meanFDR"=mean(FDR)),
    .(ensembl_id, tissue)]
ai_gene = merge(ai_gene, ai_mean, all.x=T, key="ensembl_id, tissue")

## SA genesets
# add 1/0 columns for each gene list in set to tbl based on ensembl_id
# list files should have no header and a single column
add_tfcols = function(tbl, files, names){
  fl = lapply(files, fread, header=F)
  for (i in seq(names)) {
    tbl[, names[[i]] := if(ensembl_id %in% fl[[i]][["V1"]]) 1 else 0, 
        seq_len(nrow(tbl))]
  }
}

# reading in tables, combine and melt by GWAS
f_names = c("SA_up_nac", "SA_up_nash", "SA_up_vta", "SA_down_nac", 
            "SA_down_nash", "SA_down_vta")
# up
sa_dir = paste0(rootdir, '/self_admin/dsq_split_dropvta_upgenes/')
target_files = "20200513_dsq_split_up_ultrawide_"
files = list.files(path=sa_dir, pattern=paste0(target_files, "*"), 
                   full.names=T)
# down
sa_dir2 = paste0(rootdir, '/self_admin/dsq_split_dropvta_downgenes/')
target_files2 = "20200513_dsq_split_down_ultrawide_"
files = c(files, list.files(path=sa_dir2, pattern=paste0(target_files2, "*"), 
                            full.names=T))

#add
add_tfcols(ai_gene, files, f_names)

# add gene lists they are in (Liu, Walker x2)
add_set = function(genefile, dest_tbl) {
  a = fread(genefile)
  list = unique(a$sets)
  for (i in seq(list)) {
    dest_tbl[, list[[i]] := if(ensembl_id %in% a[sets == list[[i]], 
        rnorvegicus_homolog_ensembl_gene]) 1 else 0, seq_len(nrow(dest_tbl))]
  }
}
add_set(paste0(rootdir, "/Liu_et_al_ensrog.txt"), ai_gene)
add_set(paste0(rootdir, "/Walker_AdIn_ensrog.txt"), ai_gene)
add_set(paste0(rootdir, "/Walker_SA_ensrog.txt"), ai_gene)

# reorder
setcolorder(ai_gene, c("ensembl_id", "chr", "start", "stop", "symbol", 
                    "hsapiens_ensembl_id", "hsapiens_symbol", "hsapiens_chr",
                    "tissue", "count", "snps", "bias", "meanAREF_FRAC",
                    "meanBREF_FRAC", "meanREF_FRACdiff", "meanFDR", 
                    "SA_up_nac", "SA_up_nash", "SA_up_vta", "SA_down_nac",
                    "SA_down_nash", "SA_down_vta", "AOI", "CPD", "SCe", 
                    "SIn", "DPW", "Walker_AdIn_Pos_Nac", 
                    "Walker_AdIn_Neg_Nac", "Walker_AdIn_Pos_VTA", 
                    "Walker_AdIn_Neg_VTA", "Walker_SA_Up_Nac", 
                    "Walker_SA_Down_Nac", "Walker_SA_Up_VTA", 
                    "Walker_SA_Down_VTA"))

# write snp and gene lists to tables
fwrite(ai_snp, file=paste0(today, nameset, "snps.txt"), sep="\t", 
       quote=F)
fwrite(ai_gene, file=paste0(today, nameset, "genes.txt"), sep="\t", 
       quote=F)



