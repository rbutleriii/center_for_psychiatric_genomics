#!/usr/bin/env Rscript

library(data.table)
library(VennDiagram)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi'
setwd(paste0(rootdir, '/self_admin/allelic_imbalance/prop_test'))

today = format(Sys.Date(), '%Y%m%d')
nameset = '_AI_snpset_'
groups = c("nac", "nash", "vta")

# reading in table
b = fread("20200808_AI_proptest_0.05fdr_0.1diff_snps.txt")

# venns of tissue overlaps(png)
overrideTriple=T
venn.plot = venn.diagram(x=list(
    "nac"=b[GROUP == "nac", SNP],
    "nash"=b[GROUP == "nash", SNP],
    "vta"=b[GROUP == "vta", SNP]),
  filename=paste0(today, nameset, "tissue_venn.png"), imagetype="png", 
  fill=c("cornflowerblue", "orange", "green"),
  alpha=0.50,label.col=c("darkblue", "white", "darkorange", "white", "white", 
                         "white", "darkgreen"),
  cex=1.5,fontfamily="serif",fontface="bold",col="transparent",
  cat.col=c("darkblue", "darkorange", "darkgreen"),
  cat.cex=1.5, cat.dist=0.07, cat.fontfamily="serif", main.cex=1.5,
  margin=0.2, main=paste0("SNPs with allelic imbalance in tissues"))

# set bias groups
bias_list = list("Inc"=b[`AFRAC-BFRAC` > 0 ],
                 "Dec"=b[`AFRAC-BFRAC` < 0 ])
# bias_list = list("PatInc"=b[`AFRAC-BFRAC` > 0 & AREF_FRAC < 0.5],
                 # "MatInc"=b[`AFRAC-BFRAC` > 0 & AREF_FRAC >= 0.5],
                 # "PatDec"=b[`AFRAC-BFRAC` < 0 & AREF_FRAC < 0.5],
                 # "MatDec"=b[`AFRAC-BFRAC` < 0 & AREF_FRAC >= 0.5])

# build snp.loc tables
lapply(groups, function(k) lapply(seq_along(bias_list), function(j) {
  jname = names(bias_list)[[j]]
  dt = bias_list[[j]]
  fwrite(dt[GROUP == k, c("SNP", "CHR", "BP")], 
         file=paste0(k, nameset, jname, ".loc"), sep="\t", quote=F)
}))

# # venns of overlaps per bias type(png)
# lapply(seq_along(bias_list), function(k) {
  # kname = names(bias_list)[[k]]
  # dt = bias_list[[k]]
  # venn.plot = venn.diagram(x=list("nac"=dt[GROUP == "nac", SNP],
                                  # "nash"=dt[GROUP == "nash", SNP],
                                  # "vta"=dt[GROUP == "vta", SNP]),
  # filename=paste0(today, nameset, kname, "_bias_venn.png"), imagetype="png", 
  # fill=c("cornflowerblue", "orange", "green"),
  # alpha=0.50,label.col=c("darkblue", "white", "darkorange", "white", "white", 
                         # "white", "darkgreen"),
  # cex=1.5,fontfamily="serif",fontface="bold",col="transparent",
  # cat.col=c("darkblue", "darkorange", "darkgreen"),
  # cat.cex=1.5, cat.dist=0.07, cat.fontfamily="serif", main.cex=1.5,
  # margin=0.2, main=paste0(kname, " SNPs with allelic imbalance in tissues"))
# })

