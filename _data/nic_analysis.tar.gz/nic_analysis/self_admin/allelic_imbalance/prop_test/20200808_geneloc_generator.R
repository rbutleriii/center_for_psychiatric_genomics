#!/usr/bin/env Rscript

library(biomaRt)
library(data.table)

# directory locations
rootdir = '/data/butlerr/nicotine_sensi/self_admin'
setwd(paste0(rootdir, '/allelic_imbalance/prop_test'))

# fetch from biomaRt
rat = useEnsembl("ensembl", dataset="rnorvegicus_gene_ensembl", version="99")
genes = data.table(getBM(mart=rat, attributes=c("ensembl_gene_id", 
                         "chromosome_name", "start_position", "end_position",
                         "strand", "gene_biotype")))

# ensembl transcript types to keep, excluding pseudogenes and small RNAs
# restricting to only protein coding and long rna
# # keep_categ = c('lncRNA',
               # # 'IG_C_gene',
               # # 'IG_D_gene',
               # # 'IG_J_gene',
               # # 'IG_V_gene',
               # # 'protein_coding',
               # # 'ribozyme', 
               # # 'TR_C_gene',
               # # 'TR_D_gene',
               # # 'TR_J_gene',
               # # 'TR_V_gene')
keep_categ = c('lincRNA',
               'antisense',
               'processed_transcript',
               'sense_intronic',
               'protein_coding',
               'ribozyme')
genes = subset(genes, gene_biotype %in% keep_categ)

# use only canonical chromosomes
use_chrs = c(1:20, "X", "Y")
genes = subset(genes, chromosome_name %in% use_chrs)

# fix strand
genes$strand = gsub("-1", "-", genes$strand, fixed=T)
genes$strand = gsub("1", "+", genes$strand, fixed=T)

# write to file
fwrite(genes, quote=F, col.names=F, sep="\t", 
       file="ENSRNOG_coord_biomaRt.Rnor6.txt")
# fwrite(genes_nohla, quote=F, col.names=F, sep="\t", 
       # file="ENSG_coord_biomaRt_nohla.txt")


