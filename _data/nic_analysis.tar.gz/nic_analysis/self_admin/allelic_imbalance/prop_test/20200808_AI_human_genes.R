#!/usr/bin/env Rscript

library(biomaRt)
library(data.table)

setwd('/data/butlerr/nicotine_sensi/self_admin/allelic_imbalance/prop_test')
today = format(Sys.Date(), '%Y%m%d')
nameset = "_AI_human_"
target_files = "20200808_AI_overlap_genes_genes.txt"
bac_file = "20200808_AI_overlap_genes_genes.txt"
file_tails = c("nac", "nash", "vta")

#####################################################
# Basic function to convert mouse to human gene names
convertRatGeneList = function(x){
  require("biomaRt")
  rat = useEnsembl("ensembl", dataset="rnorvegicus_gene_ensembl", version="99")
  # match with ensembl_gene_id across both
  genes = getBM(mart=rat, filters="ensembl_gene_id", values=x, 
                attributes=c("ensembl_gene_id", "chromosome_name", 
                             "start_position", "end_position", 
                             "hsapiens_homolog_ensembl_gene", 
                             "hsapiens_homolog_associated_gene_name"))
  humanx = unique(genes)
  # Print the first 6 genes found to the screen
  print(head(humanx))
  return(humanx)
}

# background set
if(!file.exists(paste0(today, nameset, "M-Hlookup.txt"))){
  background = fread(bac_file, header=T)
  bac_genes = data.table(convertRatGeneList(background$ensembl_id))
  # only those with matches
  matches = bac_genes[ hsapiens_homolog_ensembl_gene != "" ]
  fwrite(list(unique(matches$hsapiens_homolog_ensembl_gene)), quote=F, 
         col.names=F, file=paste0(today, nameset, "background.txt"))
  # set aside autosomes
  noXY = matches[ !(chromosome_name %in% c("X", "Y")) ]
  fwrite(list(unique(noXY$hsapiens_homolog_ensembl_gene)), quote=F, col.names=F, 
         file=paste0(today, nameset, "noXY_background.txt"))
  fwrite(bac_genes, quote=F, sep="\t", 
         file=paste0(today, nameset, "M-Hlookup.txt"))
} else {
  bac_genes = fread(paste0(today, nameset, "M-Hlookup.txt"))
  matches = bac_genes[ hsapiens_homolog_ensembl_gene != "" ]
}

# reading in tables, combine and melt by GWAS
file_data = fread(target_files)

# subset the DE sets by pval threshold
gene_list = function (x, outname) {
  genes = file_data[ tissue == x & bias == outname ]
  out = matches[ ensembl_gene_id %in% genes$ensembl_id ]
  f1 = paste0(today, nameset, x, outname, ".txt")
  fwrite(list(unique(out$hsapiens_homolog_ensembl_gene)), quote=F, col.names=F, 
         file=f1)
}

lapply(file_tails, function(x) gene_list(x, "Inc"))
lapply(file_tails, function(x) gene_list(x, "Dec"))

# subset the DE sets by pval threshold no XY genes
gene_list = function (x, outname) {
  genes = file_data[ tissue == x & bias == outname ]
  out = matches[ ensembl_gene_id %in% genes$ensembl_id 
                & !(chromosome_name %in% c("X", "Y")) ]
  f1 = paste0(today, nameset, "noXY_", x, outname, ".txt")
  fwrite(list(unique(out$hsapiens_homolog_ensembl_gene)), quote=F, col.names=F, 
         file=f1)
}

lapply(file_tails, function(x) gene_list(x, "Inc"))
lapply(file_tails, function(x) gene_list(x, "Dec"))

