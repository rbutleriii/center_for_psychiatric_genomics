#!/usr/bin/env bash

# script to generate a table of gene lists for DAVID
# paths to directory, date, and target file prefix
de_dir='/data/butlerr/nicotine_sensi/self_admin/allelic_imbalance/prop_test/'
de_date='20200411'
target_files='_AI_human_'
# write table header
ls ${de_dir}${de_date}${target_files}[nv][at]*.txt \
  | xargs -n1 basename \
  | sed "s/${de_date}${target_files}//g" \
  | sed "s/.txt//g" \
  | tr "\n" "\t" \
  > ${de_date}${target_files}david.table
sed -i 's/\t$/\n/' ${de_date}${target_files}david.table
# write table
paste $(ls ${de_dir}${de_date}${target_files}[nv][at]*.txt) \
  >> ${de_date}${target_files}david.table
