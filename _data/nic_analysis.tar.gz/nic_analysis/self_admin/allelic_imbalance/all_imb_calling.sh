#!/usr/bin/env bash
exec 1>> all_imb_calling.log 2>&1
set -ex

# directories for files
root_dir='/data/butlerr/nicotine_sensi'
wk_dir="${root_dir}/self_admin/allelic_imbalance"
genome_ref="${root_dir}/refs/Rattus_norvegicus.Rnor_6.0.dna.toplevel.fa"
GTF="${root_dir}/refs/Rattus_norvegicus.Rnor_6.0.96.gtf"
BED="${root_dir}/refs/Rattus_norvegicus.Rnor_6.0.96.bed"
dbSNP="${root_dir}/refs/rattus_norvegicus.dbSNP149.vcf.gz"
STAR_INDEX="${wk_dir}/Rnor6_masked"

# variables
threads=100
thr_para=23

# filenames
bams_to_merge='merge_list.txt'
merge_bam='merged.bam'
merge_vcf='merge_bam.vcf'
mask_fa='Rnor_6.0.dna_masked.fa'
fasta_to_read='../samples_list.txt'
suffix='_masked.vcf'
suffix2='_masked.g.vcf.gz'

########################################
# list of bams is two each of three tissues for A and B (12 total)
# merge bams
samtools merge -f -@ $threads -b $bams_to_merge $merge_bam
samtools index -@ $threads $merge_bam

# merge calls
gatk --java-options "-Xmx300G" HaplotypeCaller \
  -R $genome_ref \
  -D $dbSNP \
  --native-pair-hmm-threads $threads \
  -stand-call-conf 30 \
  -I $merge_bam \
  -O $merge_vcf

#######################################
# masking genome
bedtools maskfasta -fi $genome_ref -bed $merge_vcf -fo $mask_fa
samtools faidx $mask_fa

#######################################
# remapping to masked fasta

# building masked STAR index
mkdir -p $STAR_INDEX
STAR \
  --runMode genomeGenerate \
  --runThreadN $threads \
  --genomeDir $STAR_INDEX \
  --genomeFastaFiles $mask_fa \
  --sjdbGTFfile $GTF

# STAR-featureCounts pipeline
mkdir -p masked_bams
cd masked_bams

# add index to shared memory
STAR \
  --runThreadN $threads \
  --genomeDir $STAR_INDEX \
  --genomeLoad LoadAndExit

# run loop
parallel -j5 --plus \
  --rpl '{..} s:_R1_trim\.fastq\.gz::;s:/data/butlerr/nicotine_sensi/trimmed/::' \
  STAR \
    --runThreadN 20 \
    --genomeDir $STAR_INDEX \
    --genomeLoad LoadAndKeep \
    --readFilesCommand zcat \
    --outFileNamePrefix {..} \
    --outSAMtype BAM SortedByCoordinate \
    --outSAMmapqUnique 60 \
    --outSAMattrRGline ID:{..} LB:lib1 PL:illumina PU:unit1 SM:{..} \
    --outBAMsortingThreadN 10 \
    --outBAMsortingBinsN 10 \
    --limitBAMsortRAM 10000000000 \
    --outBAMcompression 10 \
    --bamRemoveDuplicatesType UniqueIdentical \
    --outFilterIntronMotifs RemoveNoncanonical \
    --outFilterMismatchNmax 2 \
    --outFilterScoreMinOverLread 0.30 \
    --outFilterMatchNminOverLread 0.30 \
    --alignSoftClipAtReferenceEnds No \
    --readFilesIn {} {/_R1_/_R2_} \
  :::: $fasta_to_read

# remove from shared memory
STAR \
  --genomeDir $STAR_INDEX \
  --genomeLoad Remove

# indexing bams
parallel -j $thr_para samtools index {} ::: *.bam
cd $wk_dir

#######################################
# # # calling vcfs from masked bams
# # mkdir -p masked_vcfs
# # parallel -j $thr_para --plus gatk --java-options \'"-Xmx4G"\' HaplotypeCaller \
  # # -R $genome_ref \
  # # -D $dbSNP \
  # # -stand-call-conf 30 \
  # # -I {} \
  # # -O masked_vcfs/{/...}${suffix} \
  # # ::: $(ls masked_bams/*.bam)

########################################
# calling gvcfs from masked bams
mkdir -p masked_gvcfs
parallel -j $thr_para --plus gatk --java-options \'"-Xmx4G"\' HaplotypeCaller \
  -R $genome_ref \
  -D $dbSNP \
  -stand-call-conf 30 \
  -I {} \
  -O masked_gvcfs/{/...}${suffix2} \
  -ERC GVCF \
  ::: $(ls masked_bams/*.bam)

cd masked_gvcfs

# tissue specific list files
ls -v *-1*Aligned_masked.g.vcf.gz | sed -r 's/(.*)Aligned/\1\t\1Aligned/' > vta.txt
ls -v *-2*Aligned_masked.g.vcf.gz | sed -r 's/(.*)Aligned/\1\t\1Aligned/' > nac.txt
ls -v *-3*Aligned_masked.g.vcf.gz | sed -r 's/(.*)Aligned/\1\t\1Aligned/' > nash.txt

# make list bed for reference genome (without patches)
awk 'BEGIN {FS="\t"}; {print $1 FS "0" FS $2}' $genome_ref.fai \
  | grep '^[1-9XY]' \
  > chr_list.bed

# make tissue specific gdbs (makes use of all 100 threads)
mkdir -p /data/butlerr/tmp
parallel -j3 gatk --java-options \'"-Xmx100G -Xms100G"\' GenomicsDBImport \
  --genomicsdb-workspace-path {} \
  --sample-name-map {}.txt \
  --max-num-intervals-to-import-in-parallel 24 \
  --intervals chr_list.bed \
  --tmp-dir=/data/butlerr/tmp \
  ::: "vta" "nac" "nash"

# call Joint Genotypes
parallel -j3 gatk --java-options \'"-Xmx40G"\' GenotypeGVCFs \
  -R $genome_ref \
  -D $dbSNP \
  -V gendb://{} \
  -L $BED \
  --merge-input-intervals true \
  --tmp-dir=/data/butlerr/tmp \
  -O {}_output.vcf.gz \
  ::: "vta" "nac" "nash"

# gatk continues to suck balls, 
# won't filter based on --interval/-L try bcftools
parallel -j3 --plus bcftools query \
  -H \
  -R $BED \
  -f\''%CHROM\t%POS\t%REF\t%ALT\t%ID[\t%AD\t%DP]\n'\' \
  -o {..}.plot \
  {} \
  ::: *output.vcf.gz

# Run plotting script extract snps
Rscript AI_proptest_plots.R

# generate overall SNP counts
for k in nac_output nash_output vta_output; 
  do 
    bcftools query -i'GT="alt"' -f'[%SAMPLE %GT \n]' $k.vcf.gz \
      | awk '{print $1}' \
      | sort | uniq -c > $k.sample.counts 
done

# cleanup
rm *output.plot
rm -rf /data/butlerr/tmp
cd ..

########################################
# merged A and B bams
mkdir -p A_B_masked_bams

# make group lists
Rscript ABgroups.R

# gatk being a pain
gatk CreateSequenceDictionary \
  -R $mask_fa

#strip out splice Ns (seems to be ablle to handle 10 at a time on ghiprd01)
parallel -j10 --plus gatk --java-options \'"-Xmx8G"\' SplitNCigarReads \
  -R $mask_fa \
  -I {} \
  -O A_B_masked_bams/{/...}.splitN.bam \
  ::: masked_bams/*.bam

# merge bams
parallel -j6 samtools merge \
  -f \
  -@ 16 \
  -b {} \
  A_B_masked_bams/{.}.merged.bam \
  ::: *.group
parallel -j6 samtools index \
  -@ 16 \
  A_B_masked_bams/{.}.merged.bam \
  ::: *.group


