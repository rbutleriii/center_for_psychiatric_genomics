#!/usr/bin/env python

'''
Robert R Butler III 2020-02-29
Pipeline for generating a gene-set analysis using MAGMA a set of gene lists.
Runs with a range of annotation windows surrounding the gene, and can 
incorporate gene-set covariate files as defined by magma
'''


# imports go here
import logging
import argparse
import os
import sys
import datetime
import subprocess as sp


# global variables
__version__ = "0.0.2"

# Directory of GWAS data
gwas = '/data/butlerr/reference/gwas'
# Directory of reference genomes
gref = '/data/butlerr/reference/bed/g1000_eur/g1000_eur'
# which gwas sets to use
gwas_set = ['AOI', 'CPD', 'DPW', 'SCe', 'SIn', 'BMI']
# gwas_set = ['AOI', 'CPD', 'DPW', 'SCe', 'SIn', 'ALZ', 'PD', 'SCZ', 'MDD', 
            # 'BIP', 'ASD', 'BMI']
# magma parallel threads, length of gwas set
thr_string = '-j' + str(len(gwas_set))

################################## functions
# argparse function
def getargs():
    parser = argparse.ArgumentParser(prog='magma_geneset.py',
                            formatter_class=argparse.RawTextHelpFormatter,
                            description='')
    # parser.add_argument('--log', action='store_true', help='create logfile')
    parser.add_argument('--long-log', action='store_true',
                        help='create detailed logfile')
    parser.add_argument('--grch38', action='store_true',
                        help='Use GRCh38 snps and genes requires:\n'
                             '  *_magma.GRCh38.sumstats for each GWAS\n'
                             '  ENSG_coord_biomaRt.GRCh38.txt for gene-locs')
    parser.add_argument('-o', metavar='log prefix', dest='outprefix',
                        default='magma_geneset',
                        help='choose alternate prefix for log files')
    parser.add_argument('-c', '--covars', nargs='*', 
            help='list of covariates to condition on \n'
                 '  (in a batch_cov.geneset file)')
    parser.add_argument('--interaction', action='store_true',
                        help='run interaction-pairs on genesets')
    parser.add_argument("--version", action='version',
            version='\n'.join(['Magma_geneset v' + __version__, __doc__]))
    # parser.add_argument("input", metavar=('file'), nargs='+',
                        # help="input file(s) (returns outfile for each)")
    requiredNamed = parser.add_argument_group('required arguments')
    requiredNamed.add_argument('-u', '--up', required=True,
                               help='upstream annotation window')
    requiredNamed.add_argument('-d', '--down', required=True,
                               help='downstream annotation window')
    requiredNamed.add_argument('-b', '--batches', nargs='*', default=['magma'],
            help='list of batch or conf threshold prefixes on geneset files\n'
                 'of the format batch_set.geneset or batch_cov.geneset')
    return parser.parse_args()

# config for error reporting
def error_handling():
    return ' {}. {}, line: {}'.format(sys.exc_info()[0], sys.exc_info()[1],
                                      sys.exc_info()[2].tb_lineno)

# choosing log options from argparse
def log_args(long_log, outprefix):
    # if log:
        # logging.basicConfig(level=logging.INFO,
                            # filename="{}.log".format(outprefix))
    if long_log:
        logging.basicConfig(level=logging.DEBUG,
                            filename="{}.log".format(outprefix))
    else:
        logging.basicConfig(level=logging.INFO,
                            filename="{}.log".format(outprefix))

# get infile list for a batchidence set
def infiles(batch):
    fdict = {}
    for r, d, files in os.walk('.'):
        for file in files:
            prefix = batch + '_'
            if file.startswith(prefix) and file.endswith('.geneset'):
                setname = os.path.splitext(file[len(prefix):])[0]
                setlist = open(os.path.join(r, file), 'r').read().splitlines()
                fdict.update( {setname : setlist} )
    return fdict

# generate [SET_FILE] with a given batch
def generate_geneset(batch):
    try:
        fdict = infiles(batch)
        assert (all(len(x) > 10 for x in fdict.values()))
        logging.info('{} gene sets: {} containing {} genes'.format(batch, 
                len(fdict), [len(x) for x in fdict.values()]))
        with open('{}.geneset'.format(batch), 'w') as out:
            out.writelines(('\t'.join([k] + v) + '\n' for k,v in fdict.items()))
        return

    except AssertionError as a:
        logging.warn(error_handling())
        print('{} set too small, skipping {}'.format(batch, error_handling()))

    except IOError as e:
        logging.fatal(error_handling())
        print('Unable to open file, {}'.format(error_handling()))

    except:
        logging.fatal(error_handling())

# getting grch38 loci
def get_38(g38):
    if g38:
        return [x + '_magma.GRCh38' for x in gwas_set], 'ENSG_coord_biomaRt.GRCh38.txt'
    else:
        return [x + '_magma' for x in gwas_set], 'ENSG_coord_biomaRt.GRCh37.txt'

# check inputs for covariates and interactions
def geneset_model(covars, interaction):
    if covars and not interaction:
        covar_str = ','.join(covars)
        return ['--model', '='.join(['condition-hide', covar_str])]
    elif covars and interaction:
        covar_str = ','.join(covars)
        return ['--model', '='.join(['condition-hide', covar_str]), 
                'interaction-pairs']
    elif not covars and interaction:
        return ['--model', 'interaction-pairs']
    else:
        return None

# build gene_annotation files
def gene_annot(up, down, outfile, sumstats, genloc):
    '''
    parallel -j5 --link magma \
      --annotate window=$upstr,$dwnstr \
      --snp-loc $gwas_dir/{3}.sumstats \
      --gene-loc $gwas_dir/{1} \
      --out {2} \
      ::: "ENSG_coord_biomaRt_nohla.txt" \
      ::: "AOI_10-1.5" "CPD_10-1.5" "DPW_10-1.5" "SCe_10-1.5" "SIn_10-1.5" \
      ::: "AOI_magma" "CPD_magma" "DPW_magma" "SCe_magma" "SIn_magma"
    '''
    cmd_list = ['parallel', thr_string, '--link', 'magma', 
            '--annotate', ''.join(['window=', up, ',', down]),
            '--snp-loc', '/'.join([gwas, '{2}.sumstats']),
            '--gene-loc', '/'.join([gwas, genloc]),
            '--out', '{1}',
            ':::', *outfile,
            ':::', *sumstats]
    logging.debug('Command to run: {}'.format(cmd_list))
    cmd = sp.Popen(cmd_list, stdout=sp.PIPE, stderr=sp.STDOUT)
    stdout, stderr = cmd.communicate()
    logging.info(stdout.decode())
    return

# gene level analysis on SNP p-values
def gene_level(outfile, sumstats):
    '''
    parallel -j5 --link magma \
      --bfile $genome_ref \
      --gene-annot {1}.genes.annot\
      --pval $gwas_dir/{2}.sumstats \
      ncol=N \
      --out {1} \
      ::: "AOI_10-1.5" "CPD_10-1.5" "DPW_10-1.5" "SCe_10-1.5" "SIn_10-1.5" \
      ::: "AOI_magma" "CPD_magma" "DPW_magma" "SCe_magma" "SIn_magma"
    '''
    cmd_list = ['parallel', thr_string, '--link', 'magma', 
            '--bfile', gref,
            '--gene-annot', '{1}.genes.annot',
            '--pval', '/'.join([gwas, '{2}.sumstats']),
            'ncol=N',
            '--out', '{1}',
            ':::', *outfile,
            ':::', *sumstats]
    logging.debug('Command to run: {}'.format(cmd_list))
    cmd = sp.Popen(cmd_list, stdout=sp.PIPE, stderr=sp.STDOUT)
    stdout, stderr = cmd.communicate()
    logging.info(stdout.decode())
    return

# gene-set analysis
def gene_set(outfile, batches, covars, interaction):
    '''
    parallel -j10 magma \
      --gene-results {1}.genes.raw \
      --set-annot {2}.geneset \
      --out {1}_{2} \
      --model condition=covars interaction-pairs \
      ::: "AOI_10-1.5" "CPD_10-1.5" "DPW_10-1.5" "SCe_10-1.5" "SIn_10-1.5" \
      ::: "narrow" "ultrawide" "wide"
    '''
    cmd_list = ['parallel', thr_string, 'magma', 
            '--gene-results', '{1}.genes.raw',
            '--set-annot', '{2}.geneset',
            '--out', '{1}_{2}',
            ':::', *outfile,
            ':::', *batches]
    # check if model
    model = geneset_model(covars, interaction)
    if model:
        cmd_list[3:3] = model
    # run
    logging.debug('Command to run: {}'.format(cmd_list))
    cmd = sp.Popen(cmd_list, stdout=sp.PIPE, stderr=sp.STDOUT)
    stdout, stderr = cmd.communicate()
    logging.info(stdout.decode())
    return

# main
def main():
    # setup args and logging
    args = getargs()
    log_args(args.long_log, args.outprefix)
    logging.info('Run date: {}'
                 .format(datetime.date.today().strftime('%Y-%m-%d')))
    logging.info('CLI inputs are up: {} down: {} outprefix: {} batches: {} covars: {}'
            .format(args.up, args.down, args.outprefix, args.batches, args.covars))

    # set values (outfile, refgenome info, covar list, confidence thresholds)
    outfile = ['_'.join([x, args.up, args.down]) for x in gwas_set]
    logging.debug('outfile list: {}'.format(outfile))
    sumstats, genloc = get_38(args.grch38)
    logging.debug('sumstats list: {}'.format(sumstats))
    logging.debug('gene-loc file {}'.format(genloc))
    covars = args.covars
    batches = args.batches
    # make genesets
    [generate_geneset(batch) for batch in batches]
    # run analyses
    gene_annot(args.up, args.down, outfile, sumstats, genloc)
    gene_level(outfile, sumstats)
    gene_set(outfile, batches, covars, args.interaction)

if __name__ == "__main__":
    main()

