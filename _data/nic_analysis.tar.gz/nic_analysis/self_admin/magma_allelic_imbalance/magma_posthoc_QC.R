#!/usr/bin/env Rscript
library(data.table)
source('posthoc_qc_107a.r')

# # file naming info
# gwas_list = c("AOI", "CPD", "DPW", "SCe", "SIn", "ALZ", "PD", "SCZ", "MDD", 
              # "BIP", "ASD", "BMI")
# prefix = paste0(gwas_list, "_20_3_cov")

# check for pvalues to refine from original 15
files = list.files(pattern="*\\.gsa.out")
names = gsub('.gsa.out', '', files)
# # reading in tables, combine and melt by GWAS
# file_list = lapply(files, function(x) fread(file=x, skip="VARIABLE"))
# setattr(file_list, 'names', names)
# file_data = rbindlist(file_list, use.names=T, idcol="FILE")

# # aggregate for min P value
# p_data = file_data[, .(MIN=min(P), MEANN=mean(NGENES), .N), by=VARIABLE ]
# p_data[MIN < 0.05 & MEANN > 10]

####### QQ plots
# error handling
testFunction <- function (k) {
  return(tryCatch(load.sets(k), error=function(e) NULL))
}

# reading in results, plot qq if notable sets
lapply(names, function(x) {
  res = testFunction(x) 
  if (!is.null(res)) plot.sets(res, x)
})

