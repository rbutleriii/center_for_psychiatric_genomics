#!/usr/bin/env Rscript
library(ggplot2)
library(data.table)

# file naming info
today = format(Sys.Date(), '%Y%m%d')
nameset = '_magma_Pvals_'

# get files for import and verify all there
files = list.files(pattern="*\\.gsa.out")
all(file.exists(files))

# reading in tables, combine and melt by GWAS
file_list = lapply(files, function(x) fread(file=x, skip="VARIABLE"))
setattr(file_list, 'names', lapply(files, function(x) {
  gsub(".gsa.out", "", x)
}))
file_data = rbindlist(file_list, use.names=T, idcol="FILE")

# clean up columns, make log10p
setnames(file_data, "VARIABLE", "TISSUE")
file_data[, c("GWAS", "UP", "DOWN", "BATCH") := tstrsplit(FILE, "_") ]
file_data[, UPDOWN := paste0(UP, "-", DOWN) ]
file_data[, c("FILE", "UP", "DOWN") := NULL ]
file_data[, LOGP := -log10(P) ]
setcolorder(file_data, c("GWAS", "BATCH", "UPDOWN", "TISSUE", "TYPE", "NGENES", 
                         "BETA", "BETA_STD", "SE", "P", "LOGP"))
fwrite(file_data, file=paste0(today, nameset, "stats.txt"),
       sep="\t", quote=F)

# plot function
plot_bars = function (k, j) {
  ggAD = ggplot(file_data[ TISSUE == k & BATCH == j], 
                aes(x=GWAS, y=LOGP, fill=UPDOWN)) +
    geom_bar(stat="identity", position=position_dodge()) +
    scale_color_brewer(type="qual", palette="Set2") +
    ggtitle(paste0(j, " ", k, " P-values for GWAS risk loci heritability")) +
    geom_hline(yintercept=1.301, linetype="dashed", col='gray') +
    geom_hline(yintercept=2.556, linetype="dashed", col='blue') +
    labs(x="gene sets", y="-log10(P)", fill="gene window (kb)") +
    theme_classic() + theme(axis.text.x=element_text(angle=45, hjust=1))
}

# plot -log(P) values for percentiles
pdf(file=paste0(today, nameset, "windows.pdf"), onefile=T, 
    paper="USr", width=11, height=8.5)
tissue = unique(file_data$TISSUE)
batch = unique(file_data$BATCH)
lapply(tissue, function(k) lapply(batch, function(j) plot_bars(k, j)))
dev.off()
