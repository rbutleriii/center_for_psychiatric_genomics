#!/usr/bin/env Rscript

library(data.table)
library(biomaRt)


#####################################################
# Basic function to convert mouse to human gene names
convertRatGeneList = function(x){
  require("biomaRt")
  human = useEnsembl("ensembl", dataset="hsapiens_gene_ensembl", version="99")
  # match with ensembl_gene_id across both
  genes = getBM(mart=human, filters="external_gene_name", values=x, 
                attributes=c("rnorvegicus_homolog_ensembl_gene"))
  humanx = unique(genes)
  # Print the first 6 genes found to the screen
  print(head(humanx))
  return(humanx)
}


# read genes
a = fread("Liu_et_al_genes.txt")

mylist = c("AOI", "CPD", "SCe", "SIn", "DPW")
step1 = lapply(mylist, function(k) convertRatGeneList(a[[k]]))
setattr(step1, 'names', mylist)
step2 = rbindlist(step1, id = 'sets')
# step2$id = with(step2, ave(rep(1, nrow(step2)), sets, FUN=seq_along))
# out = dcast(step2, id~sets, value.var="rnorvegicus_homolog_ensembl_gene")
# out[, id := NULL]
fwrite(step2, quote=F, sep="\t", file=paste0("Liu_et_al_ensrog.txt"))
