#!/usr/bin/env Rscript

library(biomaRt)
library(data.table)

# directory locations
rootdir = '/data/butlerr/reference'
setwd(paste0(rootdir, '/gwas'))

# fetch from biomaRt
human = useEnsembl("ensembl", dataset="hsapiens_gene_ensembl", version="99")
genes = data.table(getBM(mart=human, attributes=c("ensembl_gene_id", 
                         "chromosome_name", "start_position", "end_position",
                         "strand", "gene_biotype")))

# ensembl transcript types to keep, excluding pseudogenes and small RNAs
# restricting to only protein coding and long rna
keep_categ = c('lncRNA',
               'IG_C_gene',
               'IG_D_gene',
               'IG_J_gene',
               'IG_V_gene',
               'protein_coding',
               'ribozyme', 
               'TR_C_gene',
               'TR_D_gene',
               'TR_J_gene',
               'TR_V_gene')#, 
               #'vaultRNA')
genes = subset(genes, gene_biotype %in% keep_categ)

# use only canonical chromosomes
use_chrs = c(1:22)
genes = subset(genes, chromosome_name %in% use_chrs)

# fix strand
genes$strand = gsub("-1", "-", genes$strand, fixed=T)
genes$strand = gsub("1", "+", genes$strand, fixed=T)

# write to file
fwrite(genes, quote=F, col.names=F, sep="\t", 
       file="ENSG_coord_biomaRt.GRCh38.txt")
# fwrite(genes_nohla, quote=F, col.names=F, sep="\t", 
       # file="ENSG_coord_biomaRt_nohla.txt")

# genes no hla
genes_hla = subset(genes, (chromosome_name == "6" & 
                             ((start_position %in% (25000000:34000000)) | 
                              (end_position %in% (25000000:34000000))))) 

# generate gene lists for each biotype, hla
system2("mkdir", args="covariate_analysis")
# hla
fwrite(list(genes_hla$ensembl_gene_id), quote=F, col.names=F, 
       file="covariate_analysis/cov_hla.geneset")

# biotypes
lapply(keep_categ, function(x) {
  out = list(genes[gene_biotype == x, ensembl_gene_id])
  if (lengths(out) > 10) {
    fwrite(out, col.names=F, quote=F, 
           file=paste0("covariate_analysis/cov_", x, ".geneset"))
  }
})

