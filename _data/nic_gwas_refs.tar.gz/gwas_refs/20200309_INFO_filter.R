#!/usr/bin/env Rscript

library(data.table)

setwd('/data/butlerr/reference/gwas')

gwas = c("AOI", "ASD", "BIP", "CPD", "DPW", "SCe", "SCZ", "SIn")
outname = "HRC.r1-1.GRCh37.HQ_snps"

# read in files
files = paste0(gwas, "_unfiltered.txt.gz")
all(file.exists(files))

# reading in tables, combine and melt by GWAS
file_list = lapply(files, fread)
setattr(file_list, 'names', gwas)
file_data = rbindlist(file_list, use.names=T, fill=T, idcol="GWAS")
remove(file_list)

# drop unnecessary columns
file_data[, c("CHR", "BP", "A1", "A2", "P", "N", "BETA", "OR") := NULL ]

# aggregate for min INFO score and filter < 0.9
info_data = file_data[, .(MIN=min(INFO), MEAN=mean(INFO), .N), by=SNP ]
info_data = subset(info_data, MIN >= 0.9)
remove(file_data)

# select HRC SNPs that are high Q imputations
hrc = fread('HRC.r1-1.GRCh37.known_snps_maf1.txt.gz')
hrc = subset(hrc, SNP %in% info_data$SNP)
fwrite(hrc, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)