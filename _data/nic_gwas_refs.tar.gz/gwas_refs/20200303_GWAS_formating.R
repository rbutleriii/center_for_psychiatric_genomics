#!/usr/bin/env Rscript

library(data.table)

setwd('/data/butlerr/reference/gwas')

# Smoking GWAS datasets
add_info = function (table, outname) {
  x = fread(table)
  # generate info column
  x$INFO = x$EFFECTIVE_N / x$N
  # rename headers
  setnames(x, old=c("CHROM", "POS", "REF", "ALT", "RSID", "PVALUE"), 
           new=c("CHR", "BP", "A2", "A1", "SNP", "P"))
  # drop unnecessary columns
  x[, c('AF', 'STAT', 'SE', 'EFFECTIVE_N', 'Number_of_Studies', 'ANNO', 
        'ANNOFULL') := NULL ]
  # reorder and write
  setcolorder(x, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'INFO', 'BETA'))
  fwrite(x, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)
}
add_info('AgeofInitiation.txt.gz', 'AOI_unfiltered')
add_info('CigarettesPerDay.txt.gz', 'CPD_unfiltered')
add_info('DrinksPerWeek.txt.gz', 'DPW_unfiltered')
add_info('SmokingCessation.txt.gz', 'SCe_unfiltered')
add_info('SmokingInitiation.txt.gz', 'SIn_unfiltered')

# ASD GWAS dataset
outname='ASD_unfiltered'
# Add info column
x = fread("iPSYCH-PGC_ASD_Nov2017.gz")
# drop unnecessary columns
x[, SE := NULL ]
# no N column
x[, N := 18382 + 27969 ]
# rename/reorder headers
setcolorder(x, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'INFO', 'OR'))
fwrite(x, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

# BIP GWAS dataset
outname='BIP_unfiltered'
# Add info column
x = fread("daner_PGC_BIP32b_mds7a_0416a.gz")
# make N column
x[, N := sum(Nca, Nco), seq_len(nrow(x)) ]
# drop unnecessary columns
x[, c("FRQ_A_20352", "FRQ_U_31358", "SE", "ngt", "Direction", 
      "HetISqt", "HetDf", "HetPVa", "Nca", "Nco", "Neff") := NULL ]
# rename/reorder headers
setcolorder(x, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'INFO', 'OR'))
fwrite(x, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

# SCZ GWAS dataset
outname='SCZ_unfiltered'
# Add info column
x = fread("ckqny.scz2snpres.gz")
# drop unnecessary columns
x[, c("se", "ngt") := NULL ]
# no N column
x[, N := 36989 + 113075 ]
# rename/reorder headers
setnames(x, c("hg19chrc", "snpid", "a1", "a2", "bp", "p", "info", "or"), 
            c("CHR", "SNP", "A1", "A2", "BP", "P", "INFO", "OR"))
x$CHR = gsub("chr", "", x$CHR, fixed=T)
setcolorder(x, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'INFO', 'OR'))
fwrite(x, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

# ALZ GWAS dataset
outname='ALZ_unfiltered'
# Add info column
x = fread("AD_sumstats_Jansenetal_2019sept.txt.gz")
# drop unnecessary columns
x[, c("uniqID.a1a2", "Z", "Neff", "dir", "EAF", "SE") := NULL ]
# rename/reorder headers
setnames(x, "Nsum", "N")
# reorder and write
setcolorder(x, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'BETA'))
fwrite(x, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

# BMI GWAS dataset
outname='BMI_unfiltered'
# Add info column
x = fread("Meta-analysis_Locke_et_al+UKBiobank_2018_UPDATED.txt.gz")
# drop unnecessary columns
x[, c("SE", "Freq_Tested_Allele_in_HRS") := NULL ]
# rename/reorder headers
setnames(x, c("POS", "Tested_Allele", "Other_Allele"), c("BP", "A1", "A2"))
# reorder and write
setcolorder(x, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'BETA'))
fwrite(x, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

# MDD GWAS dataset
outname='MDD_unfiltered'
# Add info column
x = fread("PGC_UKB_depression_genome-wide.txt")
# drop unnecessary columns
x[, c("Freq", "StdErrLogOR") := NULL ]
# rename/reorder headers
setnames(x, "MarkerName", "SNP")
# missing GRCh37 coordinates and N
x[, N := 170756 + 329443 ]
locs37 = fread("HRC.r1-1.GRCh37.loc.gz")
x37 = merge(locs37, x, by="SNP")
# rename/reorder headers
setcolorder(x37, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'LOG_ODDS'))
fwrite(x37, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

# PD GWAS dataset
outname='PD_unfiltered'
# Add info column
x = fread(unzip("nallsEtAl2019_excluding23andMe_allVariants.tab.zip"))
# add CHR and BP from SNP
x[, c("CHR", "BP") := tstrsplit(SNP, ":", fixed=T)]
x$CHR = gsub("chr", "", x$CHR, fixed=T)
x[, CHR := as.integer(CHR) ]
x[, BP := as.integer(BP) ]
# make N column
x[, N := sum(N_cases, N_controls), seq_len(nrow(x)) ]
# drop unnecessary columns
x[, c("freq", "SNP", "se", "N_cases", "N_controls") := NULL ]
# rename/reorder headers
setnames(x, c("p", "b"), c("P", "BETA"))
# missing SNP ids
locs37 = fread("HRC.r1-1.GRCh37.loc.gz")
x37 = merge(locs37, x, by=c("CHR", "BP"))
# reorder and write
setcolorder(x37, c('SNP', 'CHR', 'BP', 'A1', 'A2', 'P', 'N', 'BETA'))
fwrite(x37, file=paste0(outname, ".txt.gz"), sep="\t", quote=F)

