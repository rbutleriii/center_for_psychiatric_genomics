#!/usr/bin/env Rscript

library(data.table)

setwd('/data/butlerr/reference/gwas')

gwas = c("ALZ", "AOI", "ASD", "BIP", "BMI", "CPD", "DPW", "MDD", "PD", "SCe", 
         "SCZ", "SIn")

# Add info column
lapply(gwas, function (k) {
  x = fread(paste0(k, "_unfiltered.txt.gz"))

  # read in munge_stats.py filtered snps and select those with signed stats
  y = fread(paste0(k, ".sumstats.gz"))
  xout = x[ SNP %in% y[!is.na(Z), SNP] ]
  fwrite(xout, file=paste0(k, "_magma.sumstats"), sep="\t", quote=F)

  # get GRCh38 coordinates for magma_GRCh38
  locs = fread("HRC.r1-1.GRCh38.loc.gz")

  # map GRCh38 coordinates to outfile
  x38 = xout[, c("CHR", "BP") := NULL ]
  l_out = merge(locs, x38, by="SNP")
  fwrite(l_out, file=paste0(k, "_magma.GRCh38.sumstats"), sep="\t", quote=F)
})

