#!/usr/bin/env Rscript
library(ggplot2)
library(data.table)

args = commandArgs(trailingOnly=TRUE)
# test if there is one argument: if not, return an error
if (length(args)!=1) {
  stop("Exactly one argument must be supplied (input file).n", call.=FALSE)
}

# directory locations
rootdir = '/data/butlerr/nicotine_sensi/self_admin'
setwd(paste0(rootdir, '/magma_split_DE'))
# file naming info
today = format(Sys.Date(), '%Y%m%d')
nameset = '_magma_Pvals_'
updown = args[1]
gwas_list = c("AOI", "CPD", "DPW", "SCe", "SIn", "ALZ", "PD", "SCZ", "MDD", 
              "BIP", "ASD", "BMI")

# get files for import and verify all there
files = list.files(pattern=paste0(".*_", updown, "_.*gsa.out"))
all(file.exists(files))

# reading in tables, combine and melt by GWAS
file_list = lapply(files, function(x) fread(file=x, skip="VARIABLE"))
setattr(file_list, 'names', lapply(files, function(x) {
  gsub(".gsa.out", "", x)
}))
file_data = rbindlist(file_list, use.names=T, idcol="FILE")

# clean up columns, make log10p
file_data[, c("GWAS", "CUTOFF") := tstrsplit(FILE, paste0("_", updown, "_")) ]
file_data[, TISSUE := sub("resAvB", "", VARIABLE) ]
file_data[, c("FILE", "VARIABLE") := NULL ]
file_data[, LOGP := -log10(P) ]
setcolorder(file_data, c("GWAS", "CUTOFF", "TISSUE", "TYPE", "NGENES", "BETA", 
                         "BETA_STD", "SE", "P", "LOGP"))
fwrite(file_data, file=paste0(today, nameset, updown, "_stats.txt"), sep="\t",
       quote=F)

# plot function
plot_bars = function (k) {
  ggAD = ggplot(file_data[GWAS == k], aes(x=TISSUE, y=LOGP, fill=CUTOFF)) +
    geom_bar(stat="identity", position=position_dodge()) +
    scale_color_brewer(type="qual", palette="Set2") +
    ggtitle(paste0(k, " P-values")) + 
    geom_hline(yintercept=2.477, linetype="dashed", col='gray') +
    labs(x="AvB DE gene sets", y="-log10(P)", fill="cutoff") +
    theme_classic() + theme(axis.text.x=element_text(angle=45, hjust=1))
}

# plot -log(P) values for percentiles
pdf(file=paste0(today, nameset, updown, "_windows.pdf"), onefile=T, paper="USr",
    width=11, height=8.5)
lapply(gwas_list, function(k) plot_bars(k))
dev.off()
