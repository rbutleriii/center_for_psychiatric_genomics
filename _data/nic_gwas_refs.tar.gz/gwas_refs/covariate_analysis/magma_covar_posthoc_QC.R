#!/usr/bin/env Rscript
library(data.table)
source('posthoc_qc_107a.r')

# directory locations
rootdir = '/data/butlerr/reference/gwas'
setwd(paste0(rootdir, '/covariate_analysis'))
# file naming info
gwas_list = c("AOI", "CPD", "DPW", "SCe", "SIn", "ALZ", "PD", "SCZ", "MDD", 
              "BIP", "ASD", "BMI")
prefix = paste0(gwas_list, "_20_3_cov")

# check for pvalues to refine from original 15
files = paste0(prefix, ".gsa.out")
# reading in tables, combine and melt by GWAS
file_list = lapply(files, function(x) fread(file=x, skip="VARIABLE"))
setattr(file_list, 'names', gwas_list)
file_data = rbindlist(file_list, use.names=T, idcol="GWAS")

# aggregate for min P value
p_data = file_data[, .(MIN=min(P), MEANN=mean(NGENES), .N), by=VARIABLE ]
p_data[MIN < 0.05 & MEANN > 10]
# 3 categories remain: 
       # VARIABLE        MIN      MEANN  N
# 1:       lncRNA 2.4416e-03 15577.7500 12
# 2:          hla 6.5136e-25   356.6667 12
# 3: protein_codi 6.8198e-07 18135.0833 12
# remove others and rerun magma_geneset.py to look at QQs

####### QQ plots
# error handling
testFunction <- function (k) {
  return(tryCatch(load.sets(k), error=function(e) NULL))
}

# reading in results, plot qq if notable sets
lapply(prefix, function(x) {
  res = testFunction(x) 
  if (!is.null(res)) plot.sets(res, x)
})

# hla, definitely
# protein_coding and lnccRNA also
# proceed with hla, protein_coding and lncRNA covariates